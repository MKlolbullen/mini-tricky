# HackAtomIQical

HackAtomIQical is a **locally hosted Trickest-style workflow builder** for bug bounty and offensive security workflows.

This version focuses on the part that actually matters first:

- a **drag-and-drop workflow canvas** in the center
- a **left toolbox** with variables, categorized tools, and search
- a **right parameter pane** for node arguments and switches
- a **bottom console** with `stdout`, `stderr`, `stdin`, plus downloadable node artifacts
- a **FastAPI backend** that loads tools from `backend/tools.yaml`, executes workflows locally, streams logs over WebSocket, and stores runs/artifacts on disk
- local **workflow templates**, **run history**, and **settings** persisted under `backend/state/`

## What changed

The original repository had a few structural problems:

- two competing frontend directions
- two competing backend directions
- broken compose wiring
- database-heavy code paths that were not aligned with the actual visual builder
- a lot of UI that looked promising but was not the app the backend could really power

This build makes the visual workflow editor the source of truth and keeps persistence simple:

- **tools** → YAML registry
- **templates/settings** → JSON files
- **runs/artifacts** → filesystem

That is a much saner foundation for a local bug bounty platform than pretending Postgres is the hard part.

## Repo layout

```text
backend/
  src/main.py           # FastAPI API + workflow runner + WebSocket log streaming
  tools.yaml            # tool registry
  state/                # generated local state (templates, settings, runs)

bug-bounty-platform/
  src/App.tsx           # main Trickest-style UI
  src/api.ts            # frontend API client
  src/index.css         # dark theme styling
```

## Quick start

### Backend

```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python src/main.py
```

Backend will listen on:

```text
http://localhost:5000
```

### Frontend

In another terminal:

```bash
cd bug-bounty-platform
npm install
npm run dev -- --host 0.0.0.0
```

Frontend will listen on:

```text
http://localhost:5173
```

## Electron desktop shell

This repo now also supports a **local Electron wrapper** so the builder runs like a desktop app while still executing the backend and security tools **locally on your machine**.

What the desktop shell does:

- starts the FastAPI backend automatically
- points the UI at the local desktop-managed API base
- keeps state under the Electron user-data directory instead of polluting the repo
- checks whether local binaries like `subfinder`, `httpx`, `nuclei`, and `ffuf` are present in `PATH`
- lets you pick local input files and open artifact files/folders directly from the UI

### Desktop prerequisites

You still need the real local tooling. Electron is the shell, not magic.

- Python 3 + backend dependencies installed
- local security tools installed in `PATH`
- frontend dependencies installed in `bug-bounty-platform/`

### Desktop dev

```bash
npm install
cd bug-bounty-platform && npm install && cd ..
npm run desktop:dev
```

### Desktop production build

```bash
npm install
cd bug-bounty-platform && npm install && cd ..
npm run desktop:build
```

The packaged app expects the bundled backend source plus a working local Python runtime.

## Docker compose

```bash
docker compose up --build
```

This starts:

- frontend on `http://localhost:5173`
- backend on `http://localhost:5000`

## Current UI behavior

### Builder

- drag tools from the left sidebar into the canvas
- drag variable nodes into the canvas for values like `domain`, `url`, `target`, or `input_file`
- connect nodes left-to-right
- select a node to edit arguments on the right
- click **Run** to execute the graph with DAG scheduling
- switch between **serial** and **parallel** execution
- enable per-node **distribution / fan-out** so a tool can split an upstream file or folder into child jobs and merge the output back into one downstream artifact

### Console

The bottom console shows per-node:

- `stdout`
- `stderr`
- `stdin` context used to launch the tool
- downloadable files created in that node’s workspace

### Templates

Templates are saved locally and can be reloaded into the builder.

### Runs

Each run stores:

- workflow metadata
- per-node status
- artifact paths
- timestamps

under:

```text
backend/state/runs/
```

## API summary

### `GET /api/tools`
Returns the YAML-backed tool registry plus built-in variable node definitions.

### `POST /api/run`
Starts a workflow run.

### `GET /api/runs`
Lists saved and active runs.

### `GET /api/templates`
Lists saved templates.

### `POST /api/templates`
Saves a template.

### `GET /api/settings`
Returns local settings.

### `PUT /api/settings`
Updates local settings.

### `WS /ws/run/{run_id}`
Streams node logs, statuses, and artifact events.

## Notes about tools

Actual node execution depends on the underlying binaries being installed locally.

So yes, the platform can orchestrate `subfinder`, `httpx`, `nuclei`, `ffuf`, etc. But no, it does not magically install your entire arsenal for you unless you do that separately or extend the Docker image to carry them.

## Good next upgrades

The current repo is now a solid local-first base. The next worthwhile upgrades are:

1. **single-node replay / resume** so you can rerun a node from cache instead of redoing the whole graph
2. **template import/export** with versioned workflow schemas
3. **typed edge contracts** so only compatible output kinds can connect to compatible input kinds
4. **result normalization** so outputs become structured entities instead of only raw files/logs
5. **project intelligence views** for subdomains, URLs, tech stack, vulnerabilities, and screenshots
6. **modules / reusable subgraphs** with exposed inputs and outputs
7. **real tool installation verification** and missing-binary detection in the UI before runtime

## Blunt truth

This is now much closer to a usable local Trickest-like platform than the uploaded version was.

The uploaded repo had ambition, but the architecture drift was winning. This version pulls it back into something you can actually build on.
