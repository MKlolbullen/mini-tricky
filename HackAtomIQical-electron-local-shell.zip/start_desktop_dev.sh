#!/bin/bash
set -e

if [ ! -d node_modules ]; then
  echo "[+] Installing Electron shell dependencies..."
  npm install
fi

if [ ! -d bug-bounty-platform/node_modules ]; then
  echo "[+] Installing frontend dependencies..."
  npm --prefix bug-bounty-platform install
fi

echo "[+] Launching HackAtomIQical desktop shell in dev mode..."
npm run desktop:dev
