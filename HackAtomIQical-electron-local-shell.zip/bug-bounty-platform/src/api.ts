const rawBase = (import.meta as any).env?.VITE_API_BASE || 'http://localhost:5000'
let resolvedApiBase = rawBase.replace(/\/$/, '')

if (typeof window !== 'undefined' && window.hackatomiqDesktop?.isDesktop) {
  resolvedApiBase = 'http://127.0.0.1:5000'
}

export const API_BASE = resolvedApiBase

function withBase(path: string): string {
  return new URL(path, `${API_BASE}/`).toString()
}

function withWs(path: string): string {
  const base = new URL(API_BASE)
  const protocol = base.protocol === 'https:' ? 'wss:' : 'ws:'
  return new URL(path, `${protocol}//${base.host}/`).toString()
}

async function fetchJson(path: string, init?: RequestInit) {
  const response = await fetch(withBase(path), init)
  if (!response.ok) {
    let detail = response.statusText
    try {
      const body = await response.json()
      detail = body.detail || body.error || detail
    } catch {
      // ignore parse failure
    }
    throw new Error(detail)
  }
  return response.json()
}

export async function listTools() {
  return fetchJson('/api/tools')
}

export async function validateWorkflow(workflow: any) {
  return fetchJson('/api/validate-workflow', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(workflow),
  })
}

export async function startRun(
  workflow: any,
  project = 'default',
  inputs: Record<string, any> = {},
  options: Record<string, any> = {},
) {
  return fetchJson('/api/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ workflow, project, inputs, options }),
  })
}

export function connectRun(runId: string, onMsg: (message: any) => void) {
  const socket = new WebSocket(withWs(`/ws/run/${runId}`))
  socket.onmessage = (event) => onMsg(JSON.parse(event.data))
  socket.onopen = () => socket.send('ready')
  return socket
}

export async function listTemplates() {
  return fetchJson('/api/templates')
}

export async function saveTemplate(template: any) {
  return fetchJson('/api/templates', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(template),
  })
}

export async function listRuns() {
  return fetchJson('/api/runs')
}

export async function getSettings() {
  return fetchJson('/api/settings')
}

export async function saveSettings(settings: any) {
  return fetchJson('/api/settings', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(settings),
  })
}

export function buildArtifactUrl(runId: string, nodeId: string, relativePath: string) {
  return withBase(`/api/runs/${runId}/artifacts/${nodeId}/${relativePath}`)
}
