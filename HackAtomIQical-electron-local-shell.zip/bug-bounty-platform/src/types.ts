export type ArgSpec =
  | { name: string; type: 'string' | 'number' | 'boolean'; label?: string; default?: any; required?: boolean }
  | { name: string; type: 'enum'; label?: string; options: string[]; default?: string }
  | { name: string; type: 'list<string>' | 'list<number>' | 'list<enum>'; label?: string; options?: string[]; default?: any[] }

export type CmdPart =
  | string
  | { kind: 'arg'; name: string; flag?: string; mode?: 'value' | 'bool' | 'repeat' | 'join'; sep?: string }

export type ToolIOSocket = {
  name: string
  label?: string
  kind?: string
  type?: string
  required?: boolean
}

export type ToolDef = {
  id: string
  label?: string
  description?: string
  cmd: CmdPart[]
  args?: ArgSpec[]
  inputs?: ToolIOSocket[]
  outputs?: ToolIOSocket[]
  out?: { kind: string; path?: string }
}

export type NodeParams = Record<string, any>
export type NodeDistribution = { enabled?: boolean; mode?: 'lines' | 'folder' | 'file_batches'; input_arg?: string; max_jobs?: number }
export type FlowNode = {
  id: string
  type: 'tool' | 'variable'
  data: {
    tool?: string
    params?: NodeParams
    label: string
    variableType?: string
    value?: string
    inputs?: ToolIOSocket[]
    outputs?: ToolIOSocket[]
    distribution?: NodeDistribution
  }
}
export type FlowEdge = {
  id: string
  source: string
  target: string
  sourceHandle?: string
  targetHandle?: string
  data?: Record<string, any>
}
export type Workflow = { id: string; name: string; nodes: FlowNode[]; edges: FlowEdge[] }
export type RunOptions = { execution_mode: 'parallel' | 'serial'; max_parallel: number; stop_on_error?: boolean }
