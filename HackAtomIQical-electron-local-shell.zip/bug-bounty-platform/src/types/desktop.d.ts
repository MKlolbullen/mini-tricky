export {}

declare global {
  interface Window {
    hackatomiqDesktop?: {
      isDesktop: boolean
      getInfo: () => Promise<{
        isDesktop: boolean
        apiBase: string
        userData: string
        stateDir: string
        backendRoot: string
        rendererEntry: string
        backendLogs?: string[]
      }>
      checkTools: (names: string[]) => Promise<Array<{ name: string; installed: boolean; path: string; error?: string }>>
      openPath: (targetPath: string) => Promise<boolean>
      openExternal: (url: string) => Promise<boolean>
      selectFile: () => Promise<string | null>
      restartBackend: () => Promise<{ apiBase: string; backendRoot: string; stateDir: string }>
      onReady: (callback: (payload: { apiBase: string; stateDir: string; backendRoot: string }) => void) => () => void
    }
  }
}
