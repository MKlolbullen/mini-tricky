// @ts-nocheck
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  addEdge,
  Background,
  ConnectionMode,
  Controls,
  Handle,
  MiniMap,
  Position,
  ReactFlow,
  useEdgesState,
  useNodesState,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import {
  Activity,
  Bug,
  Cable,
  ChevronRight,
  Copy,
  Download,
  FileJson,
  Filter,
  FolderKanban,
  FolderOpen,
  MonitorCog,
  Grip,
  LayoutTemplate,
  Loader2,
  Play,
  Plus,
  Save,
  Search,
  Settings,
  Shield,
  Terminal,
  Trash2,
  Workflow,
} from 'lucide-react'
import {
  API_BASE,
  buildArtifactUrl,
  connectRun,
  getSettings,
  listRuns,
  listTemplates,
  listTools,
  saveSettings,
  saveTemplate,
  startRun,
  validateWorkflow,
} from './api'

const WORKSPACE_KEY = 'hackatomiq.workspace.v2'
const VIEW_TABS = ['builder', 'templates', 'runs', 'settings']

const CATEGORY_LABELS = {
  reconnaissance: 'Reconnaissance',
  web_discovery: 'Web Discovery',
  fuzzing: 'Fuzzing',
  vulnerability: 'Vulnerability',
  secrets: 'Secrets',
  cloud: 'Cloud',
  utilities: 'Utilities',
  other: 'Other',
}

const VARIABLE_STYLES = {
  domain: 'from-fuchsia-500/20 to-violet-500/10 border-fuchsia-400/50',
  url: 'from-cyan-500/20 to-blue-500/10 border-cyan-400/50',
  target: 'from-emerald-500/20 to-green-500/10 border-emerald-400/50',
  input_file: 'from-amber-500/20 to-orange-500/10 border-amber-400/50',
}

function titleCase(value: string) {
  return (value || '')
    .replace(/[_-]+/g, ' ')
    .replace(/\b\w/g, (char) => char.toUpperCase())
}

function deepClone(value: any) {
  return JSON.parse(JSON.stringify(value))
}

function statusClass(status: string) {
  switch (status) {
    case 'running':
      return 'text-yellow-300 border-yellow-500/40 bg-yellow-500/10'
    case 'ok':
    case 'finished':
      return 'text-emerald-300 border-emerald-500/40 bg-emerald-500/10'
    case 'partial':
    case 'blocked':
      return 'text-amber-300 border-amber-500/40 bg-amber-500/10'
    case 'error':
      return 'text-rose-300 border-rose-500/40 bg-rose-500/10'
    default:
      return 'text-zinc-400 border-zinc-700 bg-zinc-900'
  }
}

function sanitizeToolDefaults(tool: any) {
  const params: Record<string, any> = {}
  for (const arg of tool?.args || []) {
    if (Object.prototype.hasOwnProperty.call(arg, 'default')) {
      params[arg.name] = deepClone(arg.default)
    }
  }
  return params
}

function isOutputHandle(handle: string | null | undefined) {
  return String(handle || '').startsWith('out:')
}

function defaultDistributionForTool(tool: any, data: any = {}) {
  const inputArg = data?.distribution?.input_arg || (tool?.inputs || tool?.args || []).find((entry: any) => entry.name === 'input_file')?.name || (tool?.inputs || tool?.args || [])[0]?.name || 'input_file'
  return {
    enabled: Boolean(data?.distribution?.enabled),
    mode: data?.distribution?.mode || 'lines',
    input_arg: inputArg,
    max_jobs: Number(data?.distribution?.max_jobs || 4),
  }
}

function isInputHandle(handle: string | null | undefined) {
  const raw = String(handle || '')
  return raw.startsWith('arg:') || raw.startsWith('in:')
}

function normalizeInputHandle(handle: string | null | undefined) {
  const raw = String(handle || '')
  if (raw.startsWith('arg:')) return raw
  if (raw.startsWith('in:')) return `arg:${raw.split(':', 2)[1]}`
  if (!raw) return 'arg:input_file'
  return `arg:${raw}`
}

function edgeStrokeForNode(node: any) {
  return node?.data?.kind === 'variable' ? '#d946ef' : '#06b6d4'
}

function hydrateToolData(tool: any, data: any = {}) {
  return {
    ...data,
    kind: 'tool',
    tool: tool.id,
    label: data.label || tool.label || titleCase(tool.id),
    category: data.category || tool.category || 'other',
    params: { ...sanitizeToolDefaults(tool), ...(data.params || {}) },
    inputs: (tool.inputs || tool.args || []).map((entry: any) => ({
      name: entry.name,
      label: entry.label || titleCase(entry.name),
      required: Boolean(entry.required),
      kind: entry.kind || 'value',
      type: entry.type || 'string',
    })),
    outputs: tool.outputs || [{ name: 'primary', label: 'Primary Output', kind: tool.out?.kind || 'artifact' }],
    distribution: defaultDistributionForTool(tool, data),
    status: data.status || 'idle',
  }
}

function hydrateNode(node: any, tools: any[]) {
  if (node?.data?.kind !== 'tool') {
    return {
      ...node,
      type: node.type || 'hackNode',
      data: { ...(node.data || {}), status: node?.data?.status || 'idle' },
    }
  }
  const tool = tools.find((entry) => entry.id === node?.data?.tool)
  if (!tool) {
    return {
      ...node,
      type: node.type || 'hackNode',
      data: { ...(node.data || {}), status: node?.data?.status || 'idle' },
    }
  }
  return {
    ...node,
    type: node.type || 'hackNode',
    data: hydrateToolData(tool, node.data || {}),
  }
}

function canConnectSocket(connection: any, nodes: any[]) {
  if (!connection?.source || !connection?.target) return false
  if (connection.source === connection.target) return false
  if (!isOutputHandle(connection.sourceHandle)) return false
  if (!isInputHandle(connection.targetHandle)) return false
  const sourceNode = nodes.find((node) => node.id === connection.source)
  const targetNode = nodes.find((node) => node.id === connection.target)
  if (!sourceNode || !targetNode) return false
  if (targetNode.data?.kind === 'variable') return false
  return true
}

function flowToTemplate(workflowName: string, nodes: any[], edges: any[]) {
  return {
    id: `wf-${crypto.randomUUID().slice(0, 8)}`,
    name: workflowName,
    nodes: nodes.map((node) => ({
      id: node.id,
      type: node.type || 'hackNode',
      position: node.position,
      data: {
        kind: node.data.kind,
        tool: node.data.tool,
        label: node.data.label,
        category: node.data.category,
        params: node.data.params || {},
        variableType: node.data.variableType,
        value: node.data.value,
        distribution: node.data.distribution || undefined,
      },
    })),
    edges: edges.map((edge) => ({
      id: edge.id,
      source: edge.source,
      target: edge.target,
      sourceHandle: edge.sourceHandle,
      targetHandle: normalizeInputHandle(edge.targetHandle),
      data: edge.data || {},
    })),
  }
}

function paletteCard({ title, subtitle, badge, draggable = true, onDragStart, onClick, children }: any) {
  return (
    <button
      type="button"
      draggable={draggable}
      onDragStart={onDragStart}
      onClick={onClick}
      className="w-full rounded-xl border border-zinc-800 bg-zinc-950/80 p-3 text-left transition hover:border-cyan-500/40 hover:bg-zinc-900"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <Grip className="h-3.5 w-3.5 text-zinc-500" />
            <span className="truncate text-sm font-semibold text-zinc-100">{title}</span>
          </div>
          {subtitle ? <p className="mt-1 text-xs text-zinc-400">{subtitle}</p> : null}
        </div>
        {badge ? (
          <span className="rounded-full border border-cyan-500/30 bg-cyan-500/10 px-2 py-0.5 text-[10px] uppercase tracking-wide text-cyan-200">
            {badge}
          </span>
        ) : null}
      </div>
      {children}
    </button>
  )
}

function HackNode({ data, selected }: any) {
  const isVariable = data.kind === 'variable'
  const colorClass = isVariable
    ? VARIABLE_STYLES[data.variableType] || 'from-violet-500/20 to-fuchsia-500/10 border-violet-400/50'
    : 'from-cyan-500/20 to-sky-500/10 border-cyan-400/40'
  const inputSockets = isVariable ? [] : (data.inputs || [])
  const outputHandle = isVariable ? 'out:value' : 'out:primary'
  const distribution = data.distribution || { enabled: false }

  return (
    <div
      className={`relative min-w-[230px] rounded-2xl border bg-gradient-to-br ${colorClass} p-3 shadow-xl backdrop-blur ${
        selected ? 'ring-2 ring-cyan-400/60' : ''
      }`}
    >
      {inputSockets.length ? (
        <div className="absolute -left-2 top-8 bottom-8 flex flex-col justify-center gap-2">
          {inputSockets.map((input: any) => (
            <div key={input.name} className="relative flex items-center gap-2">
              <Handle
                type="target"
                id={`arg:${input.name}`}
                position={Position.Left}
                style={{ top: 'auto', left: 0 }}
                className="!relative !left-0 !top-0 !h-3 !w-3 !border !border-zinc-950 !bg-cyan-300"
              />
              <span className="rounded-md border border-zinc-900/80 bg-zinc-950/80 px-1.5 py-0.5 text-[10px] text-zinc-300">
                {input.name}
              </span>
            </div>
          ))}
        </div>
      ) : null}

      <div className="mb-2 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="rounded-full border border-zinc-800/70 bg-zinc-950/80 px-2 py-0.5 text-[10px] uppercase tracking-[0.2em] text-zinc-400">
            {isVariable ? 'variable' : data.category || 'tool'}
          </span>
          {!isVariable && distribution.enabled ? (
            <span className="rounded-full border border-cyan-500/30 bg-cyan-500/10 px-2 py-0.5 text-[10px] uppercase tracking-wide text-cyan-200">
              dist {distribution.mode}
            </span>
          ) : null}
        </div>
        <span className={`rounded-full border px-2 py-0.5 text-[10px] uppercase tracking-wide ${statusClass(data.status || 'idle')}`}>
          {data.status || 'idle'}
        </span>
      </div>

      <div className="text-sm font-semibold text-zinc-50">{data.label}</div>
      <div className="mt-1 text-xs text-zinc-300/80">
        {isVariable ? `${titleCase(data.variableType || 'value')}: ${data.value || 'unset'}` : data.tool || 'tool'}
      </div>

      {!isVariable && inputSockets.length ? (
        <div className="mt-3 flex flex-wrap gap-1 text-[10px] text-zinc-300/80">
          {inputSockets.slice(0, 4).map((input: any) => (
            <span key={input.name} className="rounded-full border border-zinc-900/80 bg-zinc-950/70 px-2 py-0.5">
              {input.name}
            </span>
          ))}
          {inputSockets.length > 4 ? <span className="text-zinc-500">+{inputSockets.length - 4}</span> : null}
        </div>
      ) : null}

      <div className="absolute -right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
        <span className="rounded-md border border-zinc-900/80 bg-zinc-950/80 px-1.5 py-0.5 text-[10px] text-zinc-300">
          {isVariable ? 'value' : 'primary'}
        </span>
        <Handle
          type="source"
          id={outputHandle}
          position={Position.Right}
          style={{ top: '50%', right: 0 }}
          className={`!h-3 !w-3 !border !border-zinc-950 ${isVariable ? '!bg-fuchsia-300' : '!bg-cyan-300'}`}
        />
      </div>
    </div>
  )
}

const nodeTypes = { hackNode: HackNode }

export default function App() {
  const [tools, setTools] = useState<any[]>([])
  const [variables, setVariables] = useState<any[]>([])
  const [templates, setTemplates] = useState<any[]>([])
  const [runs, setRuns] = useState<any[]>([])
  const [settings, setSettings] = useState<any>({ default_project: 'default', api_base: API_BASE, execution_mode: 'parallel', max_parallel: 4 })
  const [executionMode, setExecutionMode] = useState<'parallel' | 'serial'>('parallel')
  const [maxParallel, setMaxParallel] = useState(4)
  const [activeView, setActiveView] = useState('builder')
  const [toolSearch, setToolSearch] = useState('')
  const [desktopInfo, setDesktopInfo] = useState<any>({ isDesktop: Boolean(window?.hackatomiqDesktop?.isDesktop), apiBase: API_BASE, stateDir: '' })
  const [toolAvailability, setToolAvailability] = useState<Record<string, any>>({})
  const [workflowName, setWorkflowName] = useState('Local Bug Bounty Workflow')
  const [projectName, setProjectName] = useState('default')
  const [targetInputs, setTargetInputs] = useState({ domain: '', url: '', target: '', input_file: '' })
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null)
  const [consoleTab, setConsoleTab] = useState<'stdout' | 'stderr' | 'stdin'>('stdout')
  const [runState, setRunState] = useState<any>({ runId: '', status: 'idle', error: '' })
  const [runLogs, setRunLogs] = useState<Record<string, Record<string, string[]>>>({})
  const [nodeArtifacts, setNodeArtifacts] = useState<Record<string, any[]>>({})
  const [nodeStatuses, setNodeStatuses] = useState<Record<string, string>>({})
  const [loadingState, setLoadingState] = useState({ init: true, run: false, saveTemplate: false, saveSettings: false })
  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])
  const [reactFlowInstance, setReactFlowInstance] = useState<any>(null)

  const socketRef = useRef<WebSocket | null>(null)
  const canvasRef = useRef<HTMLDivElement | null>(null)

  const setNodeData = useCallback((nodeId: string, mutate: (data: any) => any) => {
    setNodes((current) =>
      current.map((node) => (node.id === nodeId ? { ...node, data: mutate(node.data || {}) } : node)),
    )
  }, [setNodes])

  const selectedNode = useMemo(() => nodes.find((node) => node.id === selectedNodeId) || null, [nodes, selectedNodeId])
  const consoleNodeId = selectedNodeId || nodes[0]?.id || null
  const consoleNodeLogs = consoleNodeId ? runLogs[consoleNodeId] || { stdout: [], stderr: [], stdin: [] } : { stdout: [], stderr: [], stdin: [] }
  const consoleNodeArtifacts = consoleNodeId ? nodeArtifacts[consoleNodeId] || [] : []
  const isDesktop = Boolean(desktopInfo?.isDesktop || window?.hackatomiqDesktop?.isDesktop)

  useEffect(() => {
    const workspace = localStorage.getItem(WORKSPACE_KEY)
    if (!workspace) {
      return
    }
    try {
      const parsed = JSON.parse(workspace)
      if (parsed.workflowName) setWorkflowName(parsed.workflowName)
      if (parsed.projectName) setProjectName(parsed.projectName)
      if (parsed.targetInputs) setTargetInputs(parsed.targetInputs)
      if (parsed.nodes?.length) setNodes(parsed.nodes)
      if (parsed.edges?.length) setEdges(parsed.edges.map((edge: any) => ({ ...edge, targetHandle: normalizeInputHandle(edge.targetHandle) })))
    } catch {
      // ignore broken autosave
    }
  }, [setEdges, setNodes])

  useEffect(() => {
    if (!nodes.length && !edges.length && !workflowName && !projectName) {
      return
    }
    localStorage.setItem(
      WORKSPACE_KEY,
      JSON.stringify({ workflowName, projectName, targetInputs, nodes, edges }),
    )
  }, [workflowName, projectName, targetInputs, nodes, edges])

  const refreshRuns = useCallback(async () => {
    try {
      const response = await listRuns()
      setRuns(response.runs || [])
    } catch (error) {
      console.error(error)
    }
  }, [])

  const refreshTemplates = useCallback(async () => {
    try {
      const response = await listTemplates()
      setTemplates(response.templates || [])
    } catch (error) {
      console.error(error)
    }
  }, [])

  const refreshSettings = useCallback(async () => {
    try {
      const response = await getSettings()
      setSettings(response)
      setExecutionMode(response.execution_mode === 'serial' ? 'serial' : 'parallel')
      setMaxParallel(Number(response.max_parallel || 4))
      if (response.default_project) {
        setProjectName((current) => current || response.default_project)
      }
    } catch (error) {
      console.error(error)
    }
  }, [])

  useEffect(() => {
    let cancelled = false
    const removeListener = window.hackatomiqDesktop?.onReady?.((payload) => {
      if (!cancelled) {
        setDesktopInfo((current: any) => ({ ...current, ...payload, isDesktop: true }))
      }
    })

    window.hackatomiqDesktop?.getInfo?.().then((info) => {
      if (!cancelled && info) setDesktopInfo((current: any) => ({ ...current, ...info, isDesktop: true }))
    }).catch(() => {})

    return () => {
      cancelled = true
      removeListener?.()
    }
  }, [])

  useEffect(() => {
    if (!isDesktop || !tools.length || !window.hackatomiqDesktop?.checkTools) return
    window.hackatomiqDesktop.checkTools(tools.map((tool: any) => tool.cmd?.[0] || tool.id)).then((results) => {
      const next: Record<string, any> = {}
      for (const result of results || []) next[result.name] = result
      setToolAvailability(next)
    }).catch(() => {})
  }, [isDesktop, tools])

  useEffect(() => {
    let mounted = true

    async function bootstrap() {
      try {
        const [toolResponse, templateResponse, runResponse, settingsResponse] = await Promise.all([
          listTools(),
          listTemplates(),
          listRuns(),
          getSettings(),
        ])
        if (!mounted) return
        setTools(toolResponse.tools || [])
        setVariables(toolResponse.variables || [])
        setTemplates(templateResponse.templates || [])
        setRuns(runResponse.runs || [])
        setSettings(settingsResponse)
        setExecutionMode(settingsResponse.execution_mode === 'serial' ? 'serial' : 'parallel')
        setMaxParallel(Number(settingsResponse.max_parallel || 4))
        setNodes((current: any[]) => current.map((node: any) => hydrateNode(node, toolResponse.tools || [])))
        setEdges((current: any[]) => current.map((edge: any) => ({ ...edge, targetHandle: normalizeInputHandle(edge.targetHandle) })))
        if (!nodes.length && !edges.length && (templateResponse.templates || []).length) {
          const starter = templateResponse.templates[0]
          setWorkflowName(starter.workflow?.name || starter.name)
          setNodes((starter.workflow?.nodes || []).map((node: any) => hydrateNode(node, toolResponse.tools || [])))
          setEdges((starter.workflow?.edges || []).map((edge: any) => ({ ...edge, targetHandle: normalizeInputHandle(edge.targetHandle) })))
        }
      } catch (error) {
        console.error(error)
      } finally {
        if (mounted) {
          setLoadingState((current) => ({ ...current, init: false }))
        }
      }
    }

    bootstrap()
    return () => {
      mounted = false
      socketRef.current?.close()
    }
  }, [edges.length, nodes.length, setEdges, setNodes])

  const groupedTools = useMemo(() => {
    const filtered = tools.filter((tool) => {
      const haystack = `${tool.label || ''} ${tool.id || ''} ${tool.description || ''} ${tool.category || ''}`.toLowerCase()
      return haystack.includes(toolSearch.toLowerCase())
    })
    return filtered.reduce((acc: any, tool: any) => {
      const category = tool.category || 'other'
      acc[category] = acc[category] || []
      acc[category].push(tool)
      return acc
    }, {})
  }, [toolSearch, tools])

  const currentTool = useMemo(() => {
    if (!selectedNode || selectedNode.data?.kind !== 'tool') return null
    return tools.find((tool) => tool.id === selectedNode.data.tool) || null
  }, [selectedNode, tools])

  const isValidConnection = useCallback((connection: any) => canConnectSocket(connection, nodes), [nodes])

  const addToolNode = useCallback((tool: any, position: { x: number; y: number }) => {
    const nodeId = `${tool.id}-${crypto.randomUUID().slice(0, 6)}`
    const newNode = {
      id: nodeId,
      type: 'hackNode',
      position,
      data: {
        ...hydrateToolData(tool),
      },
    }
    setNodes((current) => [...current, newNode])
    setSelectedNodeId(nodeId)
  }, [setNodes])

  const addVariableNode = useCallback((variableDef: any, position: { x: number; y: number }) => {
    const nodeId = `var-${variableDef.id}-${crypto.randomUUID().slice(0, 6)}`
    const newNode = {
      id: nodeId,
      type: 'hackNode',
      position,
      data: {
        kind: 'variable',
        variableType: variableDef.id,
        label: variableDef.label,
        value: targetInputs[variableDef.id] || '',
        status: 'idle',
      },
    }
    setNodes((current) => [...current, newNode])
    setSelectedNodeId(nodeId)
  }, [setNodes, targetInputs])

  const onDragStart = useCallback((event: any, payload: any) => {
    event.dataTransfer.setData('application/hackatomiq', JSON.stringify(payload))
    event.dataTransfer.effectAllowed = 'move'
  }, [])

  const onDrop = useCallback((event: any) => {
    event.preventDefault()
    if (!reactFlowInstance || !canvasRef.current) return
    const raw = event.dataTransfer.getData('application/hackatomiq')
    if (!raw) return
    const payload = JSON.parse(raw)
    const position = reactFlowInstance.screenToFlowPosition({
      x: event.clientX,
      y: event.clientY,
    })
    if (payload.kind === 'tool') {
      addToolNode(payload.tool, position)
    }
    if (payload.kind === 'variable') {
      addVariableNode(payload.variable, position)
    }
  }, [addToolNode, addVariableNode, reactFlowInstance])

  const onDragOver = useCallback((event: any) => {
    event.preventDefault()
    event.dataTransfer.dropEffect = 'move'
  }, [])

  const onConnect = useCallback((connection: any) => {
    if (!canConnectSocket(connection, nodes)) return
    const sourceNode = nodes.find((node) => node.id === connection.source)
    const targetHandle = normalizeInputHandle(connection.targetHandle)
    setEdges((current) => {
      const filtered = current.filter((edge: any) => !(edge.target === connection.target && normalizeInputHandle(edge.targetHandle) === targetHandle))
      return addEdge(
        {
          ...connection,
          id: `edge-${crypto.randomUUID().slice(0, 8)}`,
          targetHandle,
          animated: sourceNode?.data?.kind === 'variable',
          style: { stroke: edgeStrokeForNode(sourceNode), strokeWidth: 2 },
          data: { binding: targetHandle.replace(/^arg:/, '') },
        },
        filtered,
      )
    })
  }, [nodes, setEdges])

  const applyTemplate = useCallback((template: any) => {
    setWorkflowName(template.workflow?.name || template.name)
    setNodes((template.workflow?.nodes || []).map((node: any) => hydrateNode(node, tools)))
    setEdges((template.workflow?.edges || []).map((edge: any) => ({ ...edge, targetHandle: normalizeInputHandle(edge.targetHandle) })))
    setSelectedNodeId(null)
    setRunLogs({})
    setNodeArtifacts({})
    setNodeStatuses({})
    setActiveView('builder')
  }, [setEdges, setNodes])

  const clearWorkflow = useCallback(() => {
    setNodes([])
    setEdges([])
    setSelectedNodeId(null)
    setRunLogs({})
    setNodeArtifacts({})
    setNodeStatuses({})
    setWorkflowName('Untitled Workflow')
  }, [setEdges, setNodes])

  const saveCurrentTemplate = useCallback(async () => {
    setLoadingState((current) => ({ ...current, saveTemplate: true }))
    try {
      const payload = {
        id: `tpl-${crypto.randomUUID().slice(0, 8)}`,
        name: workflowName || 'Untitled Workflow',
        description: 'Saved from the local visual builder.',
        tags: ['local', 'saved'],
        workflow: flowToTemplate(workflowName || 'Untitled Workflow', nodes, edges),
      }
      await saveTemplate(payload)
      await refreshTemplates()
      setActiveView('templates')
    } catch (error) {
      console.error(error)
      alert(`Failed to save template: ${String(error)}`)
    } finally {
      setLoadingState((current) => ({ ...current, saveTemplate: false }))
    }
  }, [edges, nodes, refreshTemplates, workflowName])

  const runWorkflowNow = useCallback(async () => {
    if (!nodes.length) {
      alert('Add at least one node before running the workflow.')
      return
    }

    socketRef.current?.close()
    setLoadingState((current) => ({ ...current, run: true }))
    setRunLogs({})
    setNodeArtifacts({})
    setRunState({ runId: '', status: 'starting', error: '' })
    const serialized = flowToTemplate(workflowName || 'Untitled Workflow', nodes, edges)

    try {
      await validateWorkflow(serialized)
      const options = {
        execution_mode: executionMode,
        max_parallel: executionMode === 'serial' ? 1 : Math.max(1, Number(maxParallel || 1)),
        stop_on_error: true,
      }
      const response = await startRun(serialized, projectName || settings.default_project || 'default', targetInputs, options)
      setRunState({ runId: response.run_id, status: response.status || 'queued', error: '' })
      setNodeStatuses({})
      setNodes((current) => current.map((node) => ({ ...node, data: { ...node.data, status: 'queued' } })))
      const socket = connectRun(response.run_id, (message: any) => {
        if (message.type === 'log') {
          setRunLogs((current) => ({
            ...current,
            [message.node]: {
              stdout: [...(current[message.node]?.stdout || []), ...(message.stream === 'stdout' ? [message.line] : [])],
              stderr: [...(current[message.node]?.stderr || []), ...(message.stream === 'stderr' ? [message.line] : [])],
              stdin: [...(current[message.node]?.stdin || []), ...(message.stream === 'stdin' ? [message.line] : [])],
            },
          }))
        }
        if (message.type === 'node_status') {
          setNodeStatuses((current) => ({ ...current, [message.node]: message.status }))
          setNodes((current) =>
            current.map((node) =>
              node.id === message.node ? { ...node, data: { ...node.data, status: message.status } } : node,
            ),
          )
        }
        if (message.type === 'node_artifacts') {
          setNodeArtifacts((current) => ({ ...current, [message.node]: message.artifacts || [] }))
        }
        if (message.type === 'run_status') {
          setRunState((current) => ({
            ...current,
            runId: message.run_id || current.runId,
            status: message.status,
            error: message.error || '',
          }))
          if (message.status === 'finished' || message.status === 'error') {
            refreshRuns()
          }
        }
      })
      socketRef.current = socket
      setActiveView('builder')
    } catch (error) {
      console.error(error)
      alert(`Failed to run workflow: ${String(error)}`)
      setRunState({ runId: '', status: 'error', error: String(error) })
    } finally {
      setLoadingState((current) => ({ ...current, run: false }))
    }
  }, [edges, executionMode, maxParallel, nodes, projectName, refreshRuns, settings.default_project, setNodes, targetInputs, workflowName])

  const updateSelectedNodeParam = useCallback((name: string, value: any) => {
    if (!selectedNodeId) return
    setNodeData(selectedNodeId, (data) => ({
      ...data,
      params: {
        ...(data.params || {}),
        [name]: value,
      },
    }))
  }, [selectedNodeId, setNodeData])

  const deleteSelectedNode = useCallback(() => {
    if (!selectedNodeId) return
    setNodes((current) => current.filter((node) => node.id !== selectedNodeId))
    setEdges((current) => current.filter((edge) => edge.source !== selectedNodeId && edge.target !== selectedNodeId))
    setSelectedNodeId(null)
  }, [selectedNodeId, setEdges, setNodes])

  const duplicateSelectedNode = useCallback(() => {
    if (!selectedNode) return
    const clone = deepClone(selectedNode)
    clone.id = `${selectedNode.id}-${crypto.randomUUID().slice(0, 4)}`
    clone.position = { x: selectedNode.position.x + 40, y: selectedNode.position.y + 40 }
    clone.data.status = 'idle'
    setNodes((current) => [...current, clone])
    setSelectedNodeId(clone.id)
  }, [selectedNode, setNodes])

  const saveSettingsNow = useCallback(async () => {
    setLoadingState((current) => ({ ...current, saveSettings: true }))
    try {
      const payload = {
        ...settings,
        default_project: projectName || settings.default_project || 'default',
        api_base: API_BASE,
        execution_mode: executionMode,
        max_parallel: executionMode === 'serial' ? 1 : Math.max(1, Number(maxParallel || 1)),
      }
      const response = await saveSettings(payload)
      setSettings(response)
    } catch (error) {
      console.error(error)
      alert(`Failed to save settings: ${String(error)}`)
    } finally {
      setLoadingState((current) => ({ ...current, saveSettings: false }))
    }
  }, [executionMode, maxParallel, projectName, settings])

  const renderArgField = (arg: any) => {
    const value = selectedNode?.data?.params?.[arg.name]

    if (arg.type === 'boolean') {
      return (
        <label key={arg.name} className="flex items-center justify-between rounded-xl border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm">
          <span>
            <span className="font-medium text-zinc-100">{arg.label || titleCase(arg.name)}</span>
            <span className="block text-xs text-zinc-500">Toggle flag</span>
          </span>
          <input
            type="checkbox"
            checked={Boolean(value)}
            onChange={(event) => updateSelectedNodeParam(arg.name, event.target.checked)}
            className="h-4 w-4 rounded border-zinc-700 bg-zinc-900 text-cyan-400"
          />
        </label>
      )
    }

    if (String(arg.type || '').startsWith('list')) {
      return (
        <label key={arg.name} className="block space-y-2 rounded-xl border border-zinc-800 bg-zinc-950 p-3">
          <span className="block text-sm font-medium text-zinc-100">{arg.label || titleCase(arg.name)}</span>
          <textarea
            rows={4}
            value={Array.isArray(value) ? value.join('\n') : ''}
            onChange={(event) => updateSelectedNodeParam(arg.name, event.target.value.split('\n').map((line) => line.trim()).filter(Boolean))}
            className="w-full rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
            placeholder="One value per line"
          />
        </label>
      )
    }

    return (
      <label key={arg.name} className="block space-y-2 rounded-xl border border-zinc-800 bg-zinc-950 p-3">
        <span className="block text-sm font-medium text-zinc-100">{arg.label || titleCase(arg.name)}</span>
        <input
          type={arg.type === 'number' ? 'number' : 'text'}
          value={value ?? ''}
          onChange={(event) =>
            updateSelectedNodeParam(arg.name, arg.type === 'number' ? Number(event.target.value) : event.target.value)
          }
          className="w-full rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
          placeholder={arg.required ? 'Required' : 'Optional'}
        />
        <div className="text-[11px] text-zinc-500">
          {arg.required ? 'Required' : 'Optional'} · {arg.type}
        </div>
      </label>
    )
  }

  const browseForInputFile = useCallback(async () => {
    const selected = await window.hackatomiqDesktop?.selectFile?.()
    if (selected) {
      setTargetInputs((current) => ({ ...current, input_file: selected }))
    }
  }, [])

  const openArtifactFolder = useCallback(async (nodeId: string, relativePath: string) => {
    if (!isDesktop || !desktopInfo?.stateDir || !runState.runId) return
    const localPath = `${desktopInfo.stateDir}/runs/${runState.runId}/${nodeId}/${relativePath}`
    await window.hackatomiqDesktop?.openPath?.(localPath)
  }, [desktopInfo?.stateDir, isDesktop, runState.runId])

  const builderView = (
    <div className="grid h-full grid-cols-[320px_minmax(0,1fr)_360px] grid-rows-[68px_minmax(0,1fr)_24vh] overflow-hidden">
      <div className="col-span-3 flex items-center justify-between gap-4 border-b border-zinc-800 bg-zinc-950/80 px-4">
        <div className="flex min-w-0 flex-1 items-center gap-3">
          <div className="rounded-xl border border-cyan-500/30 bg-cyan-500/10 p-2 text-cyan-300">
            <Workflow className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <input
              value={workflowName}
              onChange={(event) => setWorkflowName(event.target.value)}
              className="w-full border-none bg-transparent text-lg font-semibold text-zinc-100 outline-none"
            />
            <div className="flex items-center gap-2 text-xs text-zinc-500">
              <span>Local-first builder · Trickest-style layout · YAML tool registry</span>
              {isDesktop ? (
                <span className="inline-flex items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[10px] uppercase tracking-wide text-emerald-200">
                  <MonitorCog className="h-3 w-3" /> Desktop
                </span>
              ) : null}
            </div>
          </div>
        </div>

        <div className="hidden items-center gap-2 xl:flex">
          {['domain', 'url', 'target'].map((key) => (
            <input
              key={key}
              value={targetInputs[key as keyof typeof targetInputs]}
              onChange={(event) => setTargetInputs((current) => ({ ...current, [key]: event.target.value }))}
              placeholder={titleCase(key)}
              className="w-44 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
            />
          ))}
          <input
            value={projectName}
            onChange={(event) => setProjectName(event.target.value)}
            placeholder="Project"
            className="w-32 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
          />
          {isDesktop ? (
            <button
              type="button"
              onClick={browseForInputFile}
              className="inline-flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 transition hover:border-zinc-700"
            >
              <FolderOpen className="h-4 w-4" />
              {targetInputs.input_file ? 'Input file ready' : 'Pick input file'}
            </button>
          ) : null}
          <select
            value={executionMode}
            onChange={(event) => setExecutionMode(event.target.value as any)}
            className="w-32 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
          >
            <option value="parallel">Parallel</option>
            <option value="serial">Serial</option>
          </select>
          <input
            type="number"
            min={1}
            max={32}
            value={executionMode === 'serial' ? 1 : maxParallel}
            onChange={(event) => setMaxParallel(Number(event.target.value) || 1)}
            disabled={executionMode === 'serial'}
            placeholder="Workers"
            className="w-24 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500 disabled:text-zinc-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={saveCurrentTemplate}
            disabled={loadingState.saveTemplate}
            className="inline-flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 transition hover:border-zinc-700 disabled:opacity-60"
          >
            {loadingState.saveTemplate ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save Template
          </button>
          <button
            type="button"
            onClick={runWorkflowNow}
            disabled={loadingState.run}
            className="inline-flex items-center gap-2 rounded-xl border border-cyan-500/40 bg-cyan-500/15 px-3 py-2 text-sm font-medium text-cyan-100 transition hover:bg-cyan-500/20 disabled:opacity-60"
          >
            {loadingState.run ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
            Run
          </button>
        </div>
      </div>

      <aside className="row-start-2 row-end-3 overflow-auto border-r border-zinc-800 bg-zinc-950/70 px-4 py-4">
        <div className="sticky top-0 z-10 space-y-3 bg-zinc-950/90 pb-3 backdrop-blur">
          <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-3">
            <div className="flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2">
              <Search className="h-4 w-4 text-zinc-500" />
              <input
                value={toolSearch}
                onChange={(event) => setToolSearch(event.target.value)}
                placeholder="Search tools and categories"
                className="w-full border-none bg-transparent text-sm text-zinc-100 outline-none"
              />
            </div>
          </div>

          <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-3">
            <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-zinc-100">
              <Cable className="h-4 w-4 text-fuchsia-300" />
              Variables
            </div>
            <div className="space-y-2">
              {variables.map((variable) => (
                <div key={variable.id}>
                  {paletteCard({
                  title: variable.label,
                  subtitle: variable.description,
                  badge: 'input',
                  onDragStart: (event: any) => onDragStart(event, { kind: 'variable', variable }),
                  })}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-4 space-y-4">
          {Object.entries(groupedTools).map(([category, categoryTools]: any) => (
            <section key={category} className="rounded-2xl border border-zinc-800 bg-zinc-950 p-3">
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-zinc-100">{CATEGORY_LABELS[category] || titleCase(category)}</h3>
                  <p className="text-xs text-zinc-500">{categoryTools.length} tools</p>
                </div>
              </div>
              <div className="space-y-2">
                {categoryTools.map((tool: any) => (
                  <div key={tool.id}>
                    {paletteCard({
                    title: tool.label || titleCase(tool.id),
                    subtitle: tool.description,
                    badge: category.replace(/_/g, ' '),
                    onDragStart: (event: any) => onDragStart(event, { kind: 'tool', tool }),
                    children: isDesktop ? (
                      <div className="mt-2 flex items-center justify-between text-[11px]">
                        <span className={`rounded-full border px-2 py-0.5 ${(toolAvailability[tool.cmd?.[0] || tool.id]?.installed) ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : 'border-amber-500/30 bg-amber-500/10 text-amber-200'}`}>
                          {(toolAvailability[tool.cmd?.[0] || tool.id]?.installed) ? 'local binary found' : 'binary not in PATH'}
                        </span>
                      </div>
                    ) : null,
                    })}
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>
      </aside>

      <main className="relative row-start-2 row-end-3 overflow-hidden bg-[radial-gradient(circle_at_top,_rgba(8,145,178,0.12),_transparent_45%)]" ref={canvasRef}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          fitView
          onInit={setReactFlowInstance}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          connectionMode={ConnectionMode.Strict}
          isValidConnection={isValidConnection}
          onConnect={onConnect}
          onDrop={onDrop}
          onDragOver={onDragOver}
          onNodeClick={(_, node) => setSelectedNodeId(node.id)}
          onPaneClick={() => setSelectedNodeId(null)}
          colorMode="dark"
        >
          <MiniMap pannable zoomable style={{ background: '#09090b' }} />
          <Controls className="!border-zinc-800 !bg-zinc-950/80" />
          <Background gap={18} size={1} color="#1f2937" />
        </ReactFlow>

        <div className="pointer-events-none absolute left-4 top-4 rounded-2xl border border-zinc-800 bg-zinc-950/80 px-4 py-3 backdrop-blur">
          <div className="text-sm font-semibold text-zinc-100">Drop tools here</div>
          <div className="mt-1 text-xs text-zinc-500">Variables feed tools. Tool output artifacts automatically flow downstream via input_file.</div>
        </div>
      </main>

      <aside className="row-start-2 row-end-3 overflow-auto border-l border-zinc-800 bg-zinc-950/70 px-4 py-4">
        {!selectedNode ? (
          <div className="rounded-2xl border border-dashed border-zinc-700 bg-zinc-950 p-5 text-sm text-zinc-400">
            Select a node to edit parameters, toggle flags, inspect node artifacts, or duplicate/delete it.
          </div>
        ) : (
          <div className="space-y-4">
            <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-xs uppercase tracking-[0.2em] text-zinc-500">Node</div>
                  <h2 className="mt-1 text-lg font-semibold text-zinc-100">{selectedNode.data.label}</h2>
                </div>
                <span className={`rounded-full border px-2 py-1 text-xs uppercase tracking-wide ${statusClass(selectedNode.data.status || 'idle')}`}>
                  {selectedNode.data.status || 'idle'}
                </span>
              </div>
              <div className="mt-3 flex gap-2">
                <button
                  type="button"
                  onClick={duplicateSelectedNode}
                  className="inline-flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-xs text-zinc-100 transition hover:border-zinc-700"
                >
                  <Copy className="h-3.5 w-3.5" /> Duplicate
                </button>
                <button
                  type="button"
                  onClick={deleteSelectedNode}
                  className="inline-flex items-center gap-2 rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-100 transition hover:bg-rose-500/20"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Delete
                </button>
              </div>
            </div>

            {selectedNode.data.kind === 'variable' ? (
              <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4">
                <div className="text-sm font-semibold text-zinc-100">Variable value</div>
                <p className="mt-1 text-xs text-zinc-500">This node seeds the workflow context and can be connected into one or more tool nodes.</p>
                <textarea
                  rows={6}
                  value={selectedNode.data.value || ''}
                  onChange={(event) => {
                    const value = event.target.value
                    setNodeData(selectedNode.id, (data) => ({ ...data, value }))
                    setTargetInputs((current) => ({ ...current, [selectedNode.data.variableType]: value }))
                  }}
                  className="mt-3 w-full rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
                />
              </div>
            ) : (
              <div className="space-y-3">
                <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4">
                  <div className="text-sm font-semibold text-zinc-100">Tool definition</div>
                  <p className="mt-1 text-xs text-zinc-500">{currentTool?.description || 'No description available.'}</p>
                  <div className="mt-3 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 font-mono text-xs text-zinc-300">
                    {(currentTool?.cmd || []).map((part: any) => (typeof part === 'string' ? part : part.flag || `{${part.name}}`)).join(' ')}
                  </div>
                </div>

                <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-semibold text-zinc-100">Distribution / fan-out</div>
                      <p className="mt-1 text-xs text-zinc-500">Run this node as child jobs from an upstream file or folder, then merge the output back into one downstream artifact.</p>
                    </div>
                    <label className="flex items-center gap-2 text-xs text-zinc-300">
                      <span>Enable</span>
                      <input
                        type="checkbox"
                        checked={Boolean(selectedNode.data?.distribution?.enabled)}
                        onChange={(event) =>
                          setNodeData(selectedNode.id, (data) => ({
                            ...data,
                            distribution: {
                              ...(data.distribution || defaultDistributionForTool(currentTool, data)),
                              enabled: event.target.checked,
                            },
                          }))
                        }
                        className="h-4 w-4 rounded border-zinc-700 bg-zinc-900 text-cyan-400"
                      />
                    </label>
                  </div>
                  <div className="mt-4 grid gap-3 md:grid-cols-2">
                    <label className="block space-y-2">
                      <span className="text-xs uppercase tracking-wide text-zinc-500">Mode</span>
                      <select
                        value={selectedNode.data?.distribution?.mode || 'lines'}
                        onChange={(event) =>
                          setNodeData(selectedNode.id, (data) => ({
                            ...data,
                            distribution: {
                              ...(data.distribution || defaultDistributionForTool(currentTool, data)),
                              mode: event.target.value,
                            },
                          }))
                        }
                        className="w-full rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
                      >
                        <option value="lines">File lines → one child per line</option>
                        <option value="file_batches">File batches → chunk list into batches</option>
                        <option value="folder">Folder → one child per file</option>
                      </select>
                    </label>
                    <label className="block space-y-2">
                      <span className="text-xs uppercase tracking-wide text-zinc-500">Source input</span>
                      <select
                        value={selectedNode.data?.distribution?.input_arg || defaultDistributionForTool(currentTool, selectedNode.data).input_arg}
                        onChange={(event) =>
                          setNodeData(selectedNode.id, (data) => ({
                            ...data,
                            distribution: {
                              ...(data.distribution || defaultDistributionForTool(currentTool, data)),
                              input_arg: event.target.value,
                            },
                          }))
                        }
                        className="w-full rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
                      >
                        {(currentTool?.inputs || currentTool?.args || []).map((entry: any) => (
                          <option key={entry.name} value={entry.name}>
                            {entry.label || entry.name}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label className="block space-y-2">
                      <span className="text-xs uppercase tracking-wide text-zinc-500">Child job cap</span>
                      <input
                        type="number"
                        min={1}
                        max={128}
                        value={selectedNode.data?.distribution?.max_jobs || 4}
                        onChange={(event) =>
                          setNodeData(selectedNode.id, (data) => ({
                            ...data,
                            distribution: {
                              ...(data.distribution || defaultDistributionForTool(currentTool, data)),
                              max_jobs: Math.max(1, Number(event.target.value || 1)),
                            },
                          }))
                        }
                        className="w-full rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
                      />
                    </label>
                  </div>
                </div>

                {(currentTool?.args || []).map(renderArgField)}
              </div>
            )}

            <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4">
              <div className="text-sm font-semibold text-zinc-100">Artifacts</div>
              <div className="mt-3 space-y-2">
                {(nodeArtifacts[selectedNode.id] || []).length ? (
                  (nodeArtifacts[selectedNode.id] || []).map((artifact: any) => (
                    <div
                      key={artifact.relative_path}
                      className="flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 transition hover:border-cyan-500/40"
                    >
                      <a
                        href={runState.runId ? buildArtifactUrl(runState.runId, selectedNode.id, artifact.relative_path) : '#'}
                        className="min-w-0 flex-1 truncate"
                      >
                        {artifact.relative_path}
                      </a>
                      {isDesktop ? (
                        <button type="button" onClick={() => openArtifactFolder(selectedNode.id, artifact.relative_path)} className="rounded-lg border border-zinc-700 px-2 py-1 text-xs text-zinc-300 hover:border-cyan-500/40">
                          Open
                        </button>
                      ) : null}
                      <a href={runState.runId ? buildArtifactUrl(runState.runId, selectedNode.id, artifact.relative_path) : '#'}>
                        <Download className="h-4 w-4 text-zinc-500" />
                      </a>
                    </div>
                  ))
                ) : (
                  <div className="rounded-xl border border-dashed border-zinc-800 bg-zinc-900 px-3 py-3 text-xs text-zinc-500">No artifacts yet.</div>
                )}
              </div>
            </div>
          </div>
        )}
      </aside>

      <section className="col-span-3 row-start-3 row-end-4 overflow-hidden border-t border-zinc-800 bg-zinc-950/90">
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between gap-3 border-b border-zinc-800 px-4 py-2">
            <div className="flex items-center gap-2">
              <Terminal className="h-4 w-4 text-cyan-300" />
              <span className="text-sm font-semibold text-zinc-100">
                Console {consoleNodeId ? `· ${nodes.find((node) => node.id === consoleNodeId)?.data?.label}` : ''}
              </span>
              <span className={`rounded-full border px-2 py-0.5 text-[10px] uppercase tracking-wide ${statusClass(runState.status)}`}>
                {runState.status || 'idle'}
              </span>
              {runState.runId ? <span className="text-xs text-zinc-500">run {runState.runId}</span> : null}
            </div>
            <div className="flex items-center gap-1">
              {(['stdout', 'stderr', 'stdin'] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setConsoleTab(tab)}
                  className={`rounded-lg px-3 py-1.5 text-xs uppercase tracking-wide transition ${
                    consoleTab === tab ? 'bg-cyan-500/15 text-cyan-100' : 'text-zinc-400 hover:bg-zinc-900'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="grid min-h-0 flex-1 grid-cols-[minmax(0,1fr)_320px]">
            <div className="min-h-0 overflow-auto px-4 py-3 font-mono text-xs text-zinc-200">
              {(consoleNodeLogs[consoleTab] || []).length ? (
                <pre className="whitespace-pre-wrap break-words leading-6">{(consoleNodeLogs[consoleTab] || []).join('\n')}</pre>
              ) : (
                <div className="rounded-xl border border-dashed border-zinc-800 bg-zinc-900/80 p-4 text-zinc-500">
                  {runState.error && consoleTab === 'stderr' ? runState.error : `No ${consoleTab} data yet.`}
                </div>
              )}
            </div>

            <div className="border-l border-zinc-800 px-4 py-3">
              <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-zinc-100">
                <FolderKanban className="h-4 w-4 text-cyan-300" />
                Downloadable files
              </div>
              <div className="space-y-2 overflow-auto">
                {consoleNodeArtifacts.length ? (
                  consoleNodeArtifacts.map((artifact: any) => (
                    <div
                      key={artifact.relative_path}
                      className="flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 transition hover:border-cyan-500/40"
                    >
                      <a
                        href={runState.runId ? buildArtifactUrl(runState.runId, consoleNodeId, artifact.relative_path) : '#'}
                        className="min-w-0 flex-1"
                      >
                        <div className="truncate font-medium">{artifact.name}</div>
                        <div className="truncate text-xs text-zinc-500">{artifact.relative_path}</div>
                      </a>
                      {isDesktop ? (
                        <button type="button" onClick={() => openArtifactFolder(consoleNodeId, artifact.relative_path)} className="rounded-lg border border-zinc-700 px-2 py-1 text-xs text-zinc-300 hover:border-cyan-500/40">
                          Open
                        </button>
                      ) : null}
                      <a href={runState.runId ? buildArtifactUrl(runState.runId, consoleNodeId, artifact.relative_path) : '#'}>
                        <Download className="h-4 w-4 text-zinc-500" />
                      </a>
                    </div>
                  ))
                ) : (
                  <div className="rounded-xl border border-dashed border-zinc-800 bg-zinc-900 px-3 py-3 text-xs text-zinc-500">Node output files land here after execution.</div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )

  const templatesView = (
    <div className="h-full overflow-auto px-6 py-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-zinc-100">Workflow Templates</h1>
          <p className="mt-1 text-sm text-zinc-500">Load starter playbooks, fork them, and keep iterating locally.</p>
        </div>
        <button
          type="button"
          onClick={saveCurrentTemplate}
          className="inline-flex items-center gap-2 rounded-xl border border-cyan-500/40 bg-cyan-500/15 px-3 py-2 text-sm text-cyan-100 transition hover:bg-cyan-500/20"
        >
          <Save className="h-4 w-4" /> Save current workspace as template
        </button>
      </div>
      <div className="grid gap-4 xl:grid-cols-3">
        {templates.map((template: any) => (
          <article key={template.id} className="rounded-2xl border border-zinc-800 bg-zinc-950 p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="text-lg font-semibold text-zinc-100">{template.name}</h2>
                <p className="mt-1 text-sm text-zinc-500">{template.description}</p>
              </div>
              <LayoutTemplate className="h-5 w-5 text-cyan-300" />
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {(template.tags || []).map((tag: string) => (
                <span key={tag} className="rounded-full border border-zinc-800 bg-zinc-900 px-2 py-1 text-xs text-zinc-300">#{tag}</span>
              ))}
            </div>
            <div className="mt-5 flex gap-2">
              <button
                type="button"
                onClick={() => applyTemplate(template)}
                className="inline-flex items-center gap-2 rounded-xl border border-cyan-500/40 bg-cyan-500/15 px-3 py-2 text-sm text-cyan-100 transition hover:bg-cyan-500/20"
              >
                <Plus className="h-4 w-4" /> Load into builder
              </button>
              <button
                type="button"
                onClick={() => setActiveView('builder')}
                className="inline-flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 transition hover:border-zinc-700"
              >
                <ChevronRight className="h-4 w-4" /> Builder
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  )

  const runsView = (
    <div className="h-full overflow-auto px-6 py-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-zinc-100">Run History</h1>
          <p className="mt-1 text-sm text-zinc-500">Every workflow run is kept locally, with per-node status and artifact pointers.</p>
        </div>
        <button
          type="button"
          onClick={refreshRuns}
          className="inline-flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 transition hover:border-zinc-700"
        >
          <Activity className="h-4 w-4" /> Refresh
        </button>
      </div>
      <div className="space-y-3">
        {runs.map((run: any) => (
          <div key={run.id} className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-semibold text-zinc-100">{run.workflow_name || run.workflow_id}</div>
                <div className="mt-1 text-xs text-zinc-500">{run.id} · project {run.project} · started {run.started_at}</div>
              </div>
              <span className={`rounded-full border px-2 py-1 text-xs uppercase tracking-wide ${statusClass(run.status)}`}>
                {run.status}
              </span>
            </div>
            <div className="mt-4 grid gap-3 md:grid-cols-3 xl:grid-cols-5">
              {Object.entries(run.node_status || {}).map(([nodeId, status]: any) => (
                <div key={nodeId} className="rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-xs text-zinc-300">
                  <div className="font-medium text-zinc-100">{nodeId}</div>
                  <div className="mt-1 text-zinc-500">{status}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
        {!runs.length ? <div className="rounded-2xl border border-dashed border-zinc-800 bg-zinc-950 p-6 text-sm text-zinc-500">No runs yet. Build a graph and hit Run.</div> : null}
      </div>
    </div>
  )

  const settingsView = (
    <div className="h-full overflow-auto px-6 py-6">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-zinc-100">Settings</h1>
        <p className="mt-1 text-sm text-zinc-500">This keeps the app local-first and deliberately dumb in the good way: YAML for tools, JSON for templates, filesystem for run artifacts.</p>
      </div>
      <div className="grid gap-4 xl:grid-cols-2">
        <section className="rounded-2xl border border-zinc-800 bg-zinc-950 p-5">
          <div className="mb-4 flex items-center gap-2 text-lg font-semibold text-zinc-100">
            <Settings className="h-5 w-5 text-cyan-300" /> Runtime
          </div>
          <div className="space-y-4">
            <label className="block space-y-2">
              <span className="text-sm font-medium text-zinc-100">Default project</span>
              <input
                value={projectName}
                onChange={(event) => setProjectName(event.target.value)}
                className="w-full rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
              />
            </label>
            <label className="block space-y-2">
              <span className="text-sm font-medium text-zinc-100">API base</span>
              <input value={API_BASE} disabled className="w-full rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-500" />
            </label>
            <div className="grid gap-4 md:grid-cols-2">
              <label className="block space-y-2">
                <span className="text-sm font-medium text-zinc-100">Execution mode</span>
                <select
                  value={executionMode}
                  onChange={(event) => setExecutionMode(event.target.value as any)}
                  className="w-full rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
                >
                  <option value="parallel">Parallel DAG</option>
                  <option value="serial">Serial</option>
                </select>
              </label>
              <label className="block space-y-2">
                <span className="text-sm font-medium text-zinc-100">Max parallel nodes</span>
                <input
                  type="number"
                  min={1}
                  max={32}
                  value={executionMode === 'serial' ? 1 : maxParallel}
                  onChange={(event) => setMaxParallel(Number(event.target.value) || 1)}
                  disabled={executionMode === 'serial'}
                  className="w-full rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500 disabled:text-zinc-500"
                />
              </label>
            </div>
            <label className="block space-y-2">
              <span className="text-sm font-medium text-zinc-100">Notes</span>
              <textarea
                rows={5}
                value={settings.notes || ''}
                onChange={(event) => setSettings((current: any) => ({ ...current, notes: event.target.value }))}
                className="w-full rounded-xl border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
              />
            </label>
            <button
              type="button"
              onClick={saveSettingsNow}
              disabled={loadingState.saveSettings}
              className="inline-flex items-center gap-2 rounded-xl border border-cyan-500/40 bg-cyan-500/15 px-3 py-2 text-sm text-cyan-100 transition hover:bg-cyan-500/20 disabled:opacity-60"
            >
              {loadingState.saveSettings ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Save settings
            </button>
          </div>
        </section>

        <section className="rounded-2xl border border-zinc-800 bg-zinc-950 p-5">
          <div className="mb-4 flex items-center gap-2 text-lg font-semibold text-zinc-100">
            <FileJson className="h-5 w-5 text-cyan-300" /> State summary
          </div>
          <div className="space-y-3 text-sm text-zinc-300">
            <div className="rounded-xl border border-zinc-800 bg-zinc-900 px-4 py-3">Loaded tools: <span className="font-semibold text-zinc-100">{tools.length}</span></div>
            <div className="rounded-xl border border-zinc-800 bg-zinc-900 px-4 py-3">Saved templates: <span className="font-semibold text-zinc-100">{templates.length}</span></div>
            <div className="rounded-xl border border-zinc-800 bg-zinc-900 px-4 py-3">Recorded runs: <span className="font-semibold text-zinc-100">{runs.length}</span></div>
            <div className="rounded-xl border border-zinc-800 bg-zinc-900 px-4 py-3">Filesystem state dir: <span className="font-mono text-xs text-zinc-400">{settings.state_dir || 'backend/state'}</span></div>
          </div>
          <div className="mt-5 rounded-2xl border border-amber-500/20 bg-amber-500/10 p-4 text-sm text-amber-100">
            The old repo had duplicate frontend/backend paths and mismatched compose wiring. This build intentionally makes the visual builder the source of truth instead of letting drift win.
          </div>
        </section>
      </div>
    </div>
  )

  return (
    <div className="h-screen overflow-hidden bg-zinc-950 text-zinc-100">
      <header className="flex h-14 items-center justify-between border-b border-zinc-800 bg-zinc-950/95 px-5 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="rounded-xl border border-cyan-500/30 bg-cyan-500/10 p-2 text-cyan-300">
            <Shield className="h-5 w-5" />
          </div>
          <div>
            <div className="text-sm font-semibold tracking-[0.2em] text-zinc-200">HACKATOMIQICAL</div>
            <div className="text-[11px] uppercase tracking-[0.3em] text-zinc-500">local workflow platform</div>
          </div>
        </div>

        <nav className="flex items-center gap-1 rounded-2xl border border-zinc-800 bg-zinc-950 p-1">
          {VIEW_TABS.map((tab) => {
            const icon = {
              builder: Workflow,
              templates: LayoutTemplate,
              runs: Activity,
              settings: Settings,
            }[tab]
            const Icon = icon
            return (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveView(tab)}
                className={`inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm transition ${
                  activeView === tab ? 'bg-cyan-500/15 text-cyan-100' : 'text-zinc-400 hover:bg-zinc-900 hover:text-zinc-100'
                }`}
              >
                <Icon className="h-4 w-4" />
                {titleCase(tab)}
              </button>
            )
          })}
        </nav>

        <div className="flex items-center gap-2 text-xs text-zinc-500">
          <Bug className="h-4 w-4 text-cyan-300" />
          local-only · tools installed on host
        </div>
      </header>

      <div className="h-[calc(100vh-56px)]">
        {loadingState.init ? (
          <div className="flex h-full items-center justify-center gap-3 text-sm text-zinc-400">
            <Loader2 className="h-5 w-5 animate-spin text-cyan-300" /> Loading workspace, templates, tools, and settings…
          </div>
        ) : activeView === 'builder' ? (
          builderView
        ) : activeView === 'templates' ? (
          templatesView
        ) : activeView === 'runs' ? (
          runsView
        ) : (
          settingsView
        )}
      </div>
    </div>
  )
}
