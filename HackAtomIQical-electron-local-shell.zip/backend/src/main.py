from __future__ import annotations

import asyncio
import json
import logging
import os
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4

import uvicorn
import yaml
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("hackatomiq.api")

BACKEND_ROOT = Path(__file__).resolve().parents[1]
STATE_ROOT = Path(os.getenv("HACKATOMIQ_STATE_DIR", BACKEND_ROOT / "state"))
RUNS_ROOT = STATE_ROOT / "runs"
TEMPLATES_FILE = STATE_ROOT / "templates.json"
SETTINGS_FILE = STATE_ROOT / "settings.json"
TOOLS_FILE = Path(os.getenv("TOOLS_FILE", BACKEND_ROOT / "tools.yaml"))

STATE_ROOT.mkdir(parents=True, exist_ok=True)
RUNS_ROOT.mkdir(parents=True, exist_ok=True)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        logger.exception("Failed to parse JSON: %s", path)
        return default


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def safe_relpath(path: Path, root: Path) -> str:
    return str(path.resolve().relative_to(root.resolve()))


class FlowNodeModel(BaseModel):
    id: str
    type: str = "hackNode"
    position: Dict[str, float] = Field(default_factory=dict)
    data: Dict[str, Any] = Field(default_factory=dict)


class FlowEdgeModel(BaseModel):
    id: str
    source: str
    target: str
    source_handle: Optional[str] = Field(default=None, alias="sourceHandle")
    target_handle: Optional[str] = Field(default=None, alias="targetHandle")
    data: Dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class WorkflowModel(BaseModel):
    id: str = Field(default_factory=lambda: f"wf-{uuid4().hex[:8]}")
    name: str = "Untitled Workflow"
    nodes: List[FlowNodeModel] = Field(default_factory=list)
    edges: List[FlowEdgeModel] = Field(default_factory=list)


class RunOptionsModel(BaseModel):
    execution_mode: str = "parallel"
    max_parallel: int = 4
    stop_on_error: bool = True


class RunRequest(BaseModel):
    workflow: WorkflowModel
    project: str = "default"
    inputs: Dict[str, Any] = Field(default_factory=dict)
    options: RunOptionsModel = Field(default_factory=RunOptionsModel)


class TemplateModel(BaseModel):
    id: str = Field(default_factory=lambda: f"tpl-{uuid4().hex[:8]}")
    name: str
    description: str = ""
    tags: List[str] = Field(default_factory=list)
    workflow: WorkflowModel
    created_at: str = Field(default_factory=utc_now)
    updated_at: str = Field(default_factory=utc_now)


class SettingsModel(BaseModel):
    default_project: str = "default"
    notes: str = "Local-first workflow builder state"
    api_base: str = "http://localhost:5000"
    execution_mode: str = "parallel"
    max_parallel: int = 4
    updated_at: str = Field(default_factory=utc_now)


RUN_CLIENTS: Dict[str, List[WebSocket]] = {}
RUN_EVENTS: Dict[str, List[Dict[str, Any]]] = {}
RUN_SUMMARY: Dict[str, Dict[str, Any]] = {}


CATEGORY_MAP = {
    "reconnaissance": {
        "subfinder", "amass_enum", "alterx", "puredns", "shuffledns", "dnsx", "naabu", "nmap", "masscan", "chaos", "assetfinder", "sublist3r"
    },
    "web_discovery": {
        "httpx", "katana", "hakrawler", "gau", "waybackurls", "cariddi", "gauplus", "gospider", "gowitness", "waymore"
    },
    "fuzzing": {
        "ffuf", "arjun", "kiterunner", "feroxbuster", "gobuster", "dirsearch", "paramspider"
    },
    "vulnerability": {
        "nuclei", "nikto", "sqlmap", "ghauri", "xsstrike", "dalfox", "wpscan", "commix", "trivy"
    },
    "secrets": {"trufflehog", "mantra", "linkfinder", "secretfinder", "gitleaks", "go-dork"},
    "cloud": {"cloud_enum", "prowler", "scoutsuite", "azurehound", "microburst"},
    "utilities": {"anew", "unfurl", "gf", "jq", "notify"},
}


BUILTIN_VARIABLES = [
    {"id": "domain", "label": "Domain", "description": "Root domain like example.com"},
    {"id": "url", "label": "URL", "description": "Single URL target"},
    {"id": "target", "label": "Target", "description": "Generic host, URL, CIDR, or identifier"},
    {"id": "input_file", "label": "Input File", "description": "Local file path that feeds a node"},
]


DEFAULT_SETTINGS = SettingsModel().model_dump()
EMPTYISH = (None, "", [], {}, False)


if not SETTINGS_FILE.exists():
    write_json(SETTINGS_FILE, DEFAULT_SETTINGS)


with TOOLS_FILE.open("r", encoding="utf-8") as fh:
    registry = yaml.safe_load(fh) or {}

GLOBAL_ENV = registry.get("global_env", {})
TOOLS: Dict[str, Dict[str, Any]] = {}
for raw_tool in registry.get("tools", []):
    tool_id = raw_tool.get("id")
    if not tool_id:
        continue
    normalized = dict(raw_tool)
    normalized["category"] = next((cat for cat, members in CATEGORY_MAP.items() if tool_id in members), "other")
    normalized["inputs"] = [
        {
            "name": arg.get("name"),
            "label": arg.get("label", arg.get("name")),
            "kind": arg.get("io_kind") or ("file" if arg.get("name") == "input_file" else "value"),
            "type": arg.get("type", "string"),
            "required": bool(arg.get("required", False)),
        }
        for arg in normalized.get("args", []) or []
        if arg.get("name")
    ]
    out_cfg = normalized.get("out") or {}
    normalized["outputs"] = [
        {
            "name": "primary",
            "label": normalized.get("label", tool_id),
            "kind": out_cfg.get("kind", "artifact"),
            "path": out_cfg.get("path"),
        }
    ]
    TOOLS[tool_id] = normalized


# ---------- Default templates ----------
def default_templates() -> List[Dict[str, Any]]:
    def edge(edge_id: str, source: str, target: str, target_handle: str, source_handle: str = "out:primary") -> Dict[str, Any]:
        return {
            "id": edge_id,
            "source": source,
            "target": target,
            "sourceHandle": source_handle,
            "targetHandle": target_handle,
        }

    return [
        {
            "id": "tpl-recon-httpx-nuclei",
            "name": "Bug Bounty Recon → HTTPX → Nuclei",
            "description": "Subdomain discovery, validation, then vulnerability scanning.",
            "tags": ["recon", "nuclei", "starter"],
            "workflow": {
                "id": "wf-recon-httpx-nuclei",
                "name": "Recon → HTTPX → Nuclei",
                "nodes": [
                    {
                        "id": "var-domain",
                        "type": "hackNode",
                        "position": {"x": 40, "y": 220},
                        "data": {"kind": "variable", "label": "Domain", "variableType": "domain", "value": "example.com"},
                    },
                    {
                        "id": "subfinder-1",
                        "type": "hackNode",
                        "position": {"x": 300, "y": 160},
                        "data": {"kind": "tool", "tool": "subfinder", "label": "Subfinder", "params": {}},
                    },
                    {
                        "id": "httpx-1",
                        "type": "hackNode",
                        "position": {"x": 620, "y": 160},
                        "data": {"kind": "tool", "tool": "httpx", "label": "HTTPX", "params": {}},
                    },
                    {
                        "id": "nuclei-1",
                        "type": "hackNode",
                        "position": {"x": 940, "y": 160},
                        "data": {"kind": "tool", "tool": "nuclei", "label": "Nuclei", "params": {}},
                    },
                ],
                "edges": [
                    edge("e1", "var-domain", "subfinder-1", "arg:domain", "out:value"),
                    edge("e2", "subfinder-1", "httpx-1", "arg:input_file"),
                    edge("e3", "httpx-1", "nuclei-1", "arg:input_file"),
                ],
            },
            "created_at": utc_now(),
            "updated_at": utc_now(),
        },
        {
            "id": "tpl-js-hunt",
            "name": "JS Endpoint Hunt",
            "description": "Subdomain discovery, HTTP validation, then JavaScript extraction.",
            "tags": ["js", "crawler", "content"],
            "workflow": {
                "id": "wf-js-hunt",
                "name": "Subfinder → HTTPX → Katana",
                "nodes": [
                    {
                        "id": "var-domain",
                        "type": "hackNode",
                        "position": {"x": 40, "y": 220},
                        "data": {"kind": "variable", "label": "Domain", "variableType": "domain", "value": "example.com"},
                    },
                    {
                        "id": "subfinder-1",
                        "type": "hackNode",
                        "position": {"x": 300, "y": 160},
                        "data": {"kind": "tool", "tool": "subfinder", "label": "Subfinder", "params": {}},
                    },
                    {
                        "id": "httpx-1",
                        "type": "hackNode",
                        "position": {"x": 620, "y": 160},
                        "data": {"kind": "tool", "tool": "httpx", "label": "HTTPX", "params": {}},
                    },
                    {
                        "id": "katana-1",
                        "type": "hackNode",
                        "position": {"x": 940, "y": 160},
                        "data": {"kind": "tool", "tool": "katana", "label": "Katana", "params": {}},
                    },
                ],
                "edges": [
                    edge("e1", "var-domain", "subfinder-1", "arg:domain", "out:value"),
                    edge("e2", "subfinder-1", "httpx-1", "arg:input_file"),
                    edge("e3", "httpx-1", "katana-1", "arg:input_file"),
                ],
            },
            "created_at": utc_now(),
            "updated_at": utc_now(),
        },
        {
            "id": "tpl-content-discovery",
            "name": "Content Discovery",
            "description": "HTTP probing followed by directory fuzzing.",
            "tags": ["ffuf", "content", "web"],
            "workflow": {
                "id": "wf-content-discovery",
                "name": "HTTPX → FFUF",
                "nodes": [
                    {
                        "id": "var-url",
                        "type": "hackNode",
                        "position": {"x": 40, "y": 220},
                        "data": {"kind": "variable", "label": "URL", "variableType": "url", "value": "https://example.com/FUZZ"},
                    },
                    {
                        "id": "httpx-1",
                        "type": "hackNode",
                        "position": {"x": 320, "y": 160},
                        "data": {"kind": "tool", "tool": "httpx", "label": "HTTPX", "params": {"ports": ["80", "443"]}},
                    },
                    {
                        "id": "ffuf-1",
                        "type": "hackNode",
                        "position": {"x": 660, "y": 160},
                        "data": {"kind": "tool", "tool": "ffuf", "label": "FFUF", "params": {}},
                    },
                ],
                "edges": [
                    edge("e1", "var-url", "ffuf-1", "arg:url", "out:value"),
                ],
            },
            "created_at": utc_now(),
            "updated_at": utc_now(),
        },
        {
            "id": "tpl-distributed-probe-scan",
            "name": "Distributed Probe → Scan",
            "description": "Fan out HTTP probing from a list, then merge the results into a downstream scanner.",
            "tags": ["distribution", "httpx", "nuclei"],
            "workflow": {
                "id": "wf-distributed-probe-scan",
                "name": "Distributed HTTPX → Nuclei",
                "nodes": [
                    {
                        "id": "var-input",
                        "type": "hackNode",
                        "position": {"x": 40, "y": 220},
                        "data": {"kind": "variable", "label": "Input File", "variableType": "input_file", "value": "/tmp/targets.txt"},
                    },
                    {
                        "id": "httpx-1",
                        "type": "hackNode",
                        "position": {"x": 340, "y": 160},
                        "data": {
                            "kind": "tool",
                            "tool": "httpx",
                            "label": "HTTPX Distributed",
                            "params": {},
                            "distribution": {"enabled": True, "mode": "lines", "input_arg": "input_file", "max_jobs": 8},
                        },
                    },
                    {
                        "id": "nuclei-1",
                        "type": "hackNode",
                        "position": {"x": 700, "y": 160},
                        "data": {"kind": "tool", "tool": "nuclei", "label": "Nuclei", "params": {}},
                    },
                ],
                "edges": [
                    edge("e1", "var-input", "httpx-1", "arg:input_file", "out:value"),
                    edge("e2", "httpx-1", "nuclei-1", "arg:input_file"),
                ],
            },
            "created_at": utc_now(),
            "updated_at": utc_now(),
        },
    ]


if not TEMPLATES_FILE.exists():
    write_json(TEMPLATES_FILE, default_templates())


def render_value(value: Any, context: Dict[str, Any]) -> Any:
    if isinstance(value, str):
        rendered = value
        for key, val in context.items():
            rendered = rendered.replace("{{" + key + "}}", "" if val is None else str(val))
        return rendered
    if isinstance(value, list):
        return [render_value(item, context) for item in value]
    if isinstance(value, dict):
        return {k: render_value(v, context) for k, v in value.items()}
    return value


def normalize_arg_defaults(tool_def: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    defaults: Dict[str, Any] = {}
    for arg in tool_def.get("args", []) or []:
        if "default" in arg:
            defaults[arg["name"]] = render_value(arg["default"], context)
    return defaults


def coerce_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() in {"1", "true", "yes", "on"}
    return bool(value)


def apply_args(tool_def: Dict[str, Any], params: Dict[str, Any], runtime_context: Dict[str, Any]) -> Dict[str, Any]:
    values = normalize_arg_defaults(tool_def, runtime_context)
    arg_specs = {arg["name"]: arg for arg in (tool_def.get("args") or []) if arg.get("name")}
    for name, param_value in (params or {}).items():
        values[name] = render_value(param_value, runtime_context)
    for name, spec in arg_specs.items():
        values[name] = render_value(values.get(name), runtime_context)
        if spec.get("type") == "boolean":
            values[name] = coerce_bool(values.get(name))
        if spec.get("required") and values.get(name) in EMPTYISH:
            raise HTTPException(status_code=400, detail=f"Missing required argument '{name}' for tool '{tool_def['id']}'")
    return values


def build_command(tool_def: Dict[str, Any], values: Dict[str, Any], runtime_context: Dict[str, Any]) -> Tuple[List[str], Dict[str, str]]:
    context = {**runtime_context, **values}
    argv: List[str] = []
    for part in tool_def.get("cmd", []):
        if isinstance(part, str):
            argv.append(str(render_value(part, context)))
            continue
        if isinstance(part, dict) and part.get("kind") == "arg":
            name = part["name"]
            value = render_value(values.get(name), context)
            if value in EMPTYISH and value != 0:
                continue
            flag = part.get("flag", "")
            mode = part.get("mode", "value")
            if mode == "bool":
                if coerce_bool(value) and flag:
                    argv.append(flag)
            elif mode == "join":
                items = value if isinstance(value, list) else [value]
                joined = str(part.get("sep", ",")).join(str(item) for item in items)
                if flag:
                    argv.extend([flag, joined])
                else:
                    argv.append(joined)
            elif mode == "repeat":
                items = value if isinstance(value, list) else [value]
                for item in items:
                    if flag:
                        argv.extend([flag, str(item)])
                    else:
                        argv.append(str(item))
            else:
                if flag:
                    argv.extend([flag, str(value)])
                else:
                    argv.append(str(value))
            continue
        raise HTTPException(status_code=400, detail=f"Invalid command structure in tool {tool_def.get('id')}")
    env = os.environ.copy()
    env.update({str(k): str(v) for k, v in GLOBAL_ENV.items()})
    for env_spec in tool_def.get("env", []) or []:
        env_name = env_spec.get("name")
        if env_name:
            env[env_name] = str(render_value(env_spec.get("value", ""), context))
    return argv, env


def topological_order(nodes: List[FlowNodeModel], edges: List[FlowEdgeModel]) -> List[str]:
    node_ids = {node.id for node in nodes}
    adjacency: Dict[str, set[str]] = {node.id: set() for node in nodes}
    indegree: Dict[str, int] = {node.id: 0 for node in nodes}
    for edge in edges:
        if edge.source not in node_ids or edge.target not in node_ids:
            continue
        if edge.target in adjacency[edge.source]:
            continue
        adjacency[edge.source].add(edge.target)
        indegree[edge.target] += 1
    queue = deque([node.id for node in nodes if indegree[node.id] == 0])
    order: List[str] = []
    while queue:
        current = queue.popleft()
        order.append(current)
        for nxt in adjacency[current]:
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                queue.append(nxt)
    if len(order) != len(nodes):
        raise HTTPException(status_code=400, detail="Cycle detected in workflow graph")
    return order


def list_node_artifacts(node_dir: Path) -> List[Dict[str, Any]]:
    artifacts: List[Dict[str, Any]] = []
    if not node_dir.exists():
        return artifacts
    for file_path in sorted(node_dir.rglob("*")):
        if not file_path.is_file():
            continue
        artifacts.append(
            {
                "name": file_path.name,
                "relative_path": safe_relpath(file_path, node_dir),
                "size": file_path.stat().st_size,
            }
        )
    return artifacts


async def broadcast(run_id: str, message: Dict[str, Any]) -> None:
    RUN_EVENTS.setdefault(run_id, []).append(message)
    clients = RUN_CLIENTS.get(run_id, [])
    if not clients:
        return
    payload = json.dumps(message)
    dead: List[WebSocket] = []
    for ws in clients:
        try:
            await ws.send_text(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        if ws in RUN_CLIENTS.get(run_id, []):
            RUN_CLIENTS[run_id].remove(ws)


async def stream_reader(run_id: str, node_id: str, stream_name: str, stream, prefix: str = "") -> None:
    while True:
        line = await stream.readline()
        if not line:
            break
        decoded = line.decode(errors="ignore").rstrip("\n")
        await broadcast(
            run_id,
            {
                "type": "log",
                "node": node_id,
                "stream": stream_name,
                "line": f"{prefix}{decoded}" if prefix else decoded,
                "timestamp": utc_now(),
            },
        )


def edge_target_name(edge: FlowEdgeModel, target_node: FlowNodeModel) -> str:
    if edge.target_handle and edge.target_handle.startswith("arg:"):
        return edge.target_handle.split(":", 1)[1]
    if target_node.data.get("kind") == "tool":
        tool_def = TOOLS.get(target_node.data.get("tool"), {})
        for arg in tool_def.get("args", []) or []:
            if arg.get("name") == "input_file":
                return "input_file"
        args = tool_def.get("args", []) or []
        if args:
            return args[0].get("name")
    return "input_file"


def distribution_default_input_arg(tool_def: Dict[str, Any]) -> Optional[str]:
    args = tool_def.get("args", []) or []
    for arg in args:
        if arg.get("name") == "input_file":
            return "input_file"
    for arg in args:
        if arg.get("name"):
            return arg.get("name")
    return None


def normalize_distribution(node: FlowNodeModel, tool_def: Dict[str, Any]) -> Dict[str, Any]:
    raw = node.data.get("distribution") or {}
    default_arg = distribution_default_input_arg(tool_def)
    try:
        max_jobs = int(raw.get("max_jobs") or 4)
    except Exception:
        max_jobs = 4
    return {
        "enabled": bool(raw.get("enabled", False)),
        "mode": str(raw.get("mode") or "lines"),
        "input_arg": raw.get("input_arg") or default_arg,
        "max_jobs": max(1, max_jobs),
    }


def choose_distribution_input(distribution: Dict[str, Any], values: Dict[str, Any], runtime_context: Dict[str, Any]) -> Tuple[Optional[str], Optional[Path]]:
    ordered_names: List[str] = []
    preferred = distribution.get("input_arg")
    if preferred:
        ordered_names.append(preferred)
    if "input_file" not in ordered_names:
        ordered_names.append("input_file")
    for name in list(values.keys()):
        if name not in ordered_names:
            ordered_names.append(name)
    for name in ordered_names:
        candidate = runtime_context.get(name)
        if candidate in (None, ""):
            candidate = values.get(name)
        if not isinstance(candidate, str) or not candidate:
            continue
        path = Path(candidate)
        if path.exists():
            return name, path
    return None, None


def split_distribution_input(source_path: Path, mode: str, node_dir: Path, max_jobs: int) -> List[Dict[str, Any]]:
    prepared_dir = node_dir / "_dist_inputs"
    prepared_dir.mkdir(parents=True, exist_ok=True)
    jobs: List[Dict[str, Any]] = []
    if mode == "folder":
        if not source_path.is_dir():
            raise HTTPException(status_code=400, detail=f"Distribution mode 'folder' requires a directory input, got: {source_path}")
        for idx, child in enumerate(sorted(p for p in source_path.iterdir() if p.is_file()), start=1):
            jobs.append({
                "index": idx,
                "label": child.name,
                "input_path": str(child.resolve()),
            })
        return jobs

    if not source_path.is_file():
        raise HTTPException(status_code=400, detail=f"Distribution mode '{mode}' requires a file input, got: {source_path}")

    lines = [line.rstrip("\n") for line in source_path.read_text(encoding="utf-8", errors="ignore").splitlines() if line.strip()]
    if not lines:
        raise HTTPException(status_code=400, detail=f"Distribution input '{source_path.name}' is empty")

    if mode == "lines":
        for idx, line in enumerate(lines, start=1):
            child_file = prepared_dir / f"line-{idx:04d}.txt"
            child_file.write_text(line + "\n", encoding="utf-8")
            jobs.append({
                "index": idx,
                "label": line[:120],
                "input_path": str(child_file.resolve()),
            })
        return jobs

    if mode == "file_batches":
        batches = max(1, min(max_jobs, len(lines)))
        chunk_size = max(1, (len(lines) + batches - 1) // batches)
        chunk_index = 0
        for offset in range(0, len(lines), chunk_size):
            chunk_index += 1
            chunk_lines = lines[offset : offset + chunk_size]
            child_file = prepared_dir / f"batch-{chunk_index:04d}.txt"
            child_file.write_text("\n".join(chunk_lines) + "\n", encoding="utf-8")
            jobs.append({
                "index": chunk_index,
                "label": f"batch-{chunk_index} ({len(chunk_lines)} items)",
                "input_path": str(child_file.resolve()),
            })
        return jobs

    raise HTTPException(status_code=400, detail=f"Unsupported distribution mode '{mode}'")


def resolve_primary_artifact(node_dir: Path, tool_def: Dict[str, Any], runtime_context: Dict[str, Any], values: Dict[str, Any], artifacts: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    primary_artifact: Optional[Dict[str, Any]] = None
    out_cfg = tool_def.get("out") or {}
    out_path = out_cfg.get("path")
    if out_path:
        rendered_path = Path(str(render_value(out_path, {**runtime_context, **values})))
        candidate = node_dir / rendered_path
        if candidate.exists() and candidate.is_file():
            primary_artifact = {"path": str(candidate), "relative_path": safe_relpath(candidate, node_dir), "name": candidate.name}
    if primary_artifact is None and artifacts:
        first = artifacts[0]
        candidate = node_dir / first["relative_path"]
        primary_artifact = {"path": str(candidate), "relative_path": first["relative_path"], "name": first["name"]}
    return primary_artifact


async def execute_subprocess(run_id: str, node_id: str, argv: List[str], env: Dict[str, str], cwd: Path, prefix: str = "") -> int:
    try:
        process = await asyncio.create_subprocess_exec(
            *argv,
            cwd=str(cwd),
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError as exc:
        raise HTTPException(status_code=400, detail=f"Binary not found for node '{node_id}': {exc}") from exc

    await asyncio.gather(
        stream_reader(run_id, node_id, "stdout", process.stdout, prefix=prefix),
        stream_reader(run_id, node_id, "stderr", process.stderr, prefix=prefix),
    )
    return await process.wait()


def merge_distributed_outputs(node_dir: Path, tool_def: Dict[str, Any], child_results: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    primaries = [item.get("primary_artifact") for item in child_results if item.get("primary_artifact")]
    if not primaries:
        return None
    out_cfg = tool_def.get("out") or {}
    out_kind = str(out_cfg.get("kind") or "artifact")
    target_rel = out_cfg.get("path")
    if not target_rel:
        target_rel = "distributed-output.txt" if out_kind.startswith("list") or out_kind in {"artifact", "text"} else "distribution-manifest.json"
    target_path = node_dir / target_rel
    target_path.parent.mkdir(parents=True, exist_ok=True)

    if out_kind.startswith("list") or out_kind in {"artifact", "text"}:
        with target_path.open("w", encoding="utf-8") as fh:
            for primary in primaries:
                source_path = Path(primary["path"])
                if not source_path.exists() or not source_path.is_file():
                    continue
                content = source_path.read_text(encoding="utf-8", errors="ignore")
                if content:
                    fh.write(content)
                    if not content.endswith("\n"):
                        fh.write("\n")
    else:
        manifest = {
            "mode": "distributed",
            "generated_at": utc_now(),
            "children": [
                {
                    "child": item.get("child"),
                    "label": item.get("label"),
                    "returncode": item.get("returncode"),
                    "primary_artifact": item.get("primary_artifact", {}).get("relative_path") if item.get("primary_artifact") else None,
                }
                for item in child_results
            ],
        }
        target_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    return {"path": str(target_path), "relative_path": safe_relpath(target_path, node_dir), "name": target_path.name}


def validate_workflow_graph(workflow: WorkflowModel) -> None:
    nodes_by_id = {node.id: node for node in workflow.nodes}
    seen_target_sockets: set[tuple[str, str]] = set()
    for edge in workflow.edges:
        if edge.source not in nodes_by_id or edge.target not in nodes_by_id:
            raise HTTPException(status_code=400, detail=f"Edge '{edge.id}' references a missing node")
        source_node = nodes_by_id[edge.source]
        target_node = nodes_by_id[edge.target]
        if source_node.id == target_node.id:
            raise HTTPException(status_code=400, detail=f"Edge '{edge.id}' cannot connect a node to itself")
        source_handle = edge.source_handle or "out:primary"
        target_handle = edge.target_handle or edge_target_name(edge, target_node)
        if not str(source_handle).startswith("out:"):
            raise HTTPException(status_code=400, detail=f"Edge '{edge.id}' has invalid source socket '{source_handle}'")
        if not str(target_handle).startswith("arg:"):
            if str(target_handle).startswith("in:"):
                target_handle = "arg:" + str(target_handle).split(":", 1)[1]
            else:
                target_handle = f"arg:{target_handle}"
        if target_node.data.get("kind") == "variable":
            raise HTTPException(status_code=400, detail=f"Edge '{edge.id}' cannot target a variable node")
        if source_node.data.get("kind") == "tool":
            tool_def = TOOLS.get(source_node.data.get("tool"))
            if not tool_def:
                raise HTTPException(status_code=400, detail=f"Unknown tool '{source_node.data.get('tool')}' referenced by node '{source_node.id}'")
        if target_node.data.get("kind") == "tool":
            tool_def = TOOLS.get(target_node.data.get("tool"))
            if not tool_def:
                raise HTTPException(status_code=400, detail=f"Unknown tool '{target_node.data.get('tool')}' referenced by node '{target_node.id}'")
            arg_name = target_handle.split(":", 1)[1]
            valid_args = {arg.get("name") for arg in tool_def.get("args", []) or []}
            if arg_name not in valid_args:
                raise HTTPException(status_code=400, detail=f"Node '{target_node.id}' does not expose input '{arg_name}'")
        target_socket_key = (edge.target, target_handle)
        if target_socket_key in seen_target_sockets:
            raise HTTPException(status_code=400, detail=f"Input socket '{target_handle}' on node '{edge.target}' already has a connection")
        seen_target_sockets.add(target_socket_key)

    for node in workflow.nodes:
        if node.data.get("kind") != "tool":
            continue
        tool_def = TOOLS.get(node.data.get("tool"))
        if not tool_def:
            continue
        distribution = normalize_distribution(node, tool_def)
        if not distribution.get("enabled"):
            continue
        if distribution.get("mode") not in {"lines", "folder", "file_batches"}:
            raise HTTPException(status_code=400, detail=f"Node '{node.id}' has unsupported distribution mode '{distribution.get('mode')}'")
        input_arg = distribution.get("input_arg")
        valid_args = {arg.get("name") for arg in tool_def.get("args", []) or []}
        if input_arg and input_arg not in valid_args:
            raise HTTPException(status_code=400, detail=f"Node '{node.id}' cannot distribute on missing input '{input_arg}'")
    topological_order(workflow.nodes, workflow.edges)


async def execute_node(
    run_id: str,
    node: FlowNodeModel,
    node_dir: Path,
    incoming_edges: List[FlowEdgeModel],
    nodes_by_id: Dict[str, FlowNodeModel],
    run_request: RunRequest,
    resolved_variables: Dict[str, Any],
    latest_artifact_by_node: Dict[str, Dict[str, Any]],
    run_meta: Dict[str, Any],
) -> Tuple[str, Optional[Dict[str, Any]], List[Dict[str, Any]]]:
    node_id = node.id
    node_kind = node.data.get("kind", "tool")
    node_dir.mkdir(parents=True, exist_ok=True)
    run_meta["node_status"][node_id] = "running"

    if node_kind == "variable":
        variable_type = node.data.get("variableType") or node.data.get("name") or "target"
        value = node.data.get("value")
        if value in (None, ""):
            value = run_request.inputs.get(variable_type) or run_request.inputs.get("target")
        resolved_variables[node_id] = value
        await broadcast(run_id, {"type": "node_status", "node": node_id, "status": "running"})
        await broadcast(
            run_id,
            {
                "type": "log",
                "node": node_id,
                "stream": "stdout",
                "line": f"Resolved {variable_type} = {value}",
                "timestamp": utc_now(),
            },
        )
        run_meta["node_status"][node_id] = "ok"
        await broadcast(run_id, {"type": "node_status", "node": node_id, "status": "ok", "kind": "variable"})
        return "ok", None, []

    tool_id = node.data.get("tool")
    tool_def = TOOLS.get(tool_id)
    if not tool_def:
        raise HTTPException(status_code=400, detail=f"Unknown tool '{tool_id}' referenced by node '{node_id}'")

    runtime_context: Dict[str, Any] = {
        **run_request.inputs,
        "workspace": str(node_dir),
        "project": run_request.project,
        "run_id": run_id,
        "workflow_name": run_request.workflow.name,
    }

    for edge in incoming_edges:
        source_node = nodes_by_id[edge.source]
        arg_name = edge_target_name(edge, node)
        if source_node.data.get("kind") == "variable":
            variable_name = source_node.data.get("variableType") or "target"
            variable_value = resolved_variables.get(source_node.id)
            runtime_context[arg_name] = variable_value
            runtime_context[variable_name] = variable_value
            if variable_name in {"domain", "url", "target"} and not runtime_context.get("target"):
                runtime_context["target"] = variable_value
        else:
            artifact_info = latest_artifact_by_node.get(source_node.id)
            if artifact_info:
                runtime_context[arg_name] = artifact_info.get("path")
                runtime_context.setdefault("upstream_artifact", artifact_info.get("path"))
                if arg_name == "input_file":
                    runtime_context["input_file"] = artifact_info.get("path")

    params = node.data.get("params") or {}
    values = apply_args(tool_def, params, runtime_context)
    argv, env = build_command(tool_def, values, runtime_context)
    distribution = normalize_distribution(node, tool_def)

    await broadcast(run_id, {"type": "node_status", "node": node_id, "status": "running", "argv": argv})
    await broadcast(
        run_id,
        {
            "type": "log",
            "node": node_id,
            "stream": "stdin",
            "line": json.dumps({"argv": argv, "resolved": values, "context": runtime_context, "distribution": distribution}, ensure_ascii=False),
            "timestamp": utc_now(),
        },
    )

    if distribution.get("enabled"):
        input_arg, source_path = choose_distribution_input(distribution, values, runtime_context)
        if not input_arg or source_path is None:
            raise HTTPException(status_code=400, detail=f"Node '{node_id}' has distribution enabled but no readable source input was found")
        child_jobs = split_distribution_input(source_path, distribution.get("mode") or "lines", node_dir, distribution.get("max_jobs") or 4)
        child_limit = max(1, min(int(distribution.get("max_jobs") or 1), int(run_request.options.max_parallel or 1)))
        run_meta.setdefault("distributed", {})[node_id] = {
            "mode": distribution.get("mode"),
            "input_arg": input_arg,
            "children": len(child_jobs),
            "max_parallel": child_limit,
        }
        await broadcast(run_id, {"type": "log", "node": node_id, "stream": "stdout", "line": f"Distribution enabled: {len(child_jobs)} child jobs via {distribution.get('mode')} on {input_arg}", "timestamp": utc_now()})

        semaphore = asyncio.Semaphore(child_limit)
        child_results: List[Dict[str, Any]] = []

        async def run_child(job: Dict[str, Any]) -> Dict[str, Any]:
            async with semaphore:
                child_index = int(job["index"])
                child_dir = node_dir / "_dist" / f"child-{child_index:04d}"
                child_dir.mkdir(parents=True, exist_ok=True)
                child_context = dict(runtime_context)
                child_context["workspace"] = str(child_dir)
                child_context["child_index"] = child_index
                child_context["input_file"] = job["input_path"]
                child_context[input_arg] = job["input_path"]
                child_values = dict(values)
                child_values[input_arg] = job["input_path"]
                if "input_file" in {arg.get("name") for arg in tool_def.get("args", []) or []}:
                    child_values["input_file"] = job["input_path"]
                child_argv, child_env = build_command(tool_def, child_values, child_context)
                prefix = f"[child {child_index}] "
                await broadcast(run_id, {"type": "log", "node": node_id, "stream": "stdin", "line": prefix + json.dumps({"label": job["label"], "argv": child_argv}, ensure_ascii=False), "timestamp": utc_now()})
                return_code = await execute_subprocess(run_id, node_id, child_argv, child_env, child_dir, prefix=prefix)
                child_artifacts = list_node_artifacts(child_dir)
                primary_artifact = resolve_primary_artifact(child_dir, tool_def, child_context, child_values, child_artifacts)
                result = {
                    "child": child_index,
                    "label": job["label"],
                    "returncode": return_code,
                    "artifacts": child_artifacts,
                    "primary_artifact": primary_artifact,
                }
                if return_code != 0:
                    raise HTTPException(status_code=400, detail=f"Node '{node_id}' child {child_index} exited with status {return_code}")
                return result

        child_results = await asyncio.gather(*(run_child(job) for job in child_jobs))
        manifest_path = node_dir / "distribution-manifest.json"
        manifest_payload = {
            "node": node_id,
            "tool": tool_id,
            "mode": distribution.get("mode"),
            "input_arg": input_arg,
            "children": [
                {
                    "child": item["child"],
                    "label": item["label"],
                    "returncode": item["returncode"],
                    "primary_artifact": item["primary_artifact"],
                }
                for item in child_results
            ],
        }
        manifest_path.write_text(json.dumps(manifest_payload, indent=2, ensure_ascii=False), encoding="utf-8")
        primary_artifact = merge_distributed_outputs(node_dir, tool_def, child_results)
        artifacts = list_node_artifacts(node_dir)
        run_meta["artifacts"][node_id] = artifacts
        node_status = "ok"
        run_meta["node_status"][node_id] = node_status
        await broadcast(run_id, {"type": "node_artifacts", "node": node_id, "artifacts": artifacts})
        await broadcast(run_id, {"type": "node_status", "node": node_id, "status": node_status, "returncode": 0, "primary_artifact": primary_artifact, "distributed": manifest_payload})
        return node_status, primary_artifact, artifacts

    return_code = await execute_subprocess(run_id, node_id, argv, env, node_dir)
    artifacts = list_node_artifacts(node_dir)
    run_meta["artifacts"][node_id] = artifacts
    primary_artifact = resolve_primary_artifact(node_dir, tool_def, runtime_context, values, artifacts)

    node_status = "ok" if return_code == 0 else "error"
    run_meta["node_status"][node_id] = node_status
    await broadcast(run_id, {"type": "node_artifacts", "node": node_id, "artifacts": artifacts})
    await broadcast(
        run_id,
        {
            "type": "node_status",
            "node": node_id,
            "status": node_status,
            "returncode": return_code,
            "primary_artifact": primary_artifact,
        },
    )
    if return_code != 0:
        raise HTTPException(status_code=400, detail=f"Node '{node_id}' exited with status {return_code}")
    return node_status, primary_artifact, artifacts


async def execute_workflow(run_id: str, run_request: RunRequest) -> None:
    workflow = run_request.workflow
    validate_workflow_graph(workflow)

    run_dir = RUNS_ROOT / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "workflow.json").write_text(workflow.model_dump_json(indent=2, by_alias=True), encoding="utf-8")

    nodes_by_id = {node.id: node for node in workflow.nodes}
    incoming: Dict[str, List[FlowEdgeModel]] = {node.id: [] for node in workflow.nodes}
    outgoing: Dict[str, List[str]] = {node.id: [] for node in workflow.nodes}
    indegree: Dict[str, int] = {node.id: 0 for node in workflow.nodes}
    for edge in workflow.edges:
        incoming.setdefault(edge.target, []).append(edge)
        outgoing.setdefault(edge.source, []).append(edge.target)
        indegree[edge.target] += 1

    order = topological_order(workflow.nodes, workflow.edges)
    requested_mode = (run_request.options.execution_mode or "parallel").lower()
    max_parallel = max(1, int(run_request.options.max_parallel or 1))
    if requested_mode == "serial":
        max_parallel = 1

    run_meta = {
        "id": run_id,
        "project": run_request.project,
        "workflow_id": workflow.id,
        "workflow_name": workflow.name,
        "status": "running",
        "started_at": utc_now(),
        "finished_at": None,
        "node_status": {node.id: "pending" for node in workflow.nodes},
        "artifacts": {},
        "inputs": run_request.inputs,
        "options": run_request.options.model_dump(),
    }
    RUN_SUMMARY[run_id] = run_meta
    await broadcast(
        run_id,
        {
            "type": "run_status",
            "run_id": run_id,
            "status": "started",
            "order": order,
            "execution_mode": requested_mode,
            "max_parallel": max_parallel,
        },
    )

    resolved_variables: Dict[str, Any] = {}
    latest_artifact_by_node: Dict[str, Dict[str, Any]] = {}
    node_results: Dict[str, Dict[str, Any]] = {}
    ready = asyncio.Queue()
    for node_id, degree in indegree.items():
        if degree == 0:
            await ready.put(node_id)

    abort_on_error = bool(run_request.options.stop_on_error)
    hard_error = False
    hard_error_text = ""
    processed: set[str] = set()
    processing: set[str] = set()

    async def worker(worker_id: int) -> None:
        nonlocal hard_error, hard_error_text
        while True:
            try:
                node_id = await asyncio.wait_for(ready.get(), timeout=0.2)
            except asyncio.TimeoutError:
                if len(processed) >= len(nodes_by_id):
                    break
                continue
            if node_id in processed:
                ready.task_done()
                continue
            node = nodes_by_id[node_id]
            if hard_error and abort_on_error:
                run_meta["node_status"][node_id] = "blocked"
                processed.add(node_id)
                await broadcast(run_id, {"type": "node_status", "node": node_id, "status": "blocked", "reason": hard_error_text or "upstream failure"})
                ready.task_done()
                for child_id in outgoing.get(node_id, []):
                    if child_id in processed or child_id in processing:
                        continue
                    parent_statuses = [run_meta["node_status"].get(parent.id if isinstance(parent, FlowNodeModel) else parent) for parent in []]
                    if all(run_meta["node_status"].get(edge.source) not in {"pending", "running"} for edge in incoming.get(child_id, [])):
                        await ready.put(child_id)
                continue

            upstream_statuses = [run_meta["node_status"].get(edge.source, "pending") for edge in incoming.get(node_id, [])]
            if any(status in {"pending", "running"} for status in upstream_statuses):
                await ready.put(node_id)
                ready.task_done()
                await asyncio.sleep(0.05)
                continue
            if any(status != "ok" for status in upstream_statuses):
                run_meta["node_status"][node_id] = "blocked"
                processed.add(node_id)
                await broadcast(run_id, {"type": "node_status", "node": node_id, "status": "blocked", "reason": "parent_failed"})
                ready.task_done()
                for child_id in outgoing.get(node_id, []):
                    if child_id not in processed:
                        await ready.put(child_id)
                continue

            processing.add(node_id)
            try:
                status, primary_artifact, artifacts = await execute_node(
                    run_id=run_id,
                    node=node,
                    node_dir=run_dir / node_id,
                    incoming_edges=incoming.get(node_id, []),
                    nodes_by_id=nodes_by_id,
                    run_request=run_request,
                    resolved_variables=resolved_variables,
                    latest_artifact_by_node=latest_artifact_by_node,
                    run_meta=run_meta,
                )
                node_results[node_id] = {"status": status, "artifacts": artifacts, "primary_artifact": primary_artifact}
                if primary_artifact:
                    latest_artifact_by_node[node_id] = primary_artifact
            except Exception as exc:
                logger.exception("Workflow run %s node %s failed", run_id, node_id)
                run_meta["node_status"][node_id] = "error"
                hard_error = True
                hard_error_text = str(exc)
                await broadcast(run_id, {"type": "run_log", "level": "error", "node": node_id, "line": str(exc), "timestamp": utc_now()})
                await broadcast(run_id, {"type": "node_status", "node": node_id, "status": "error", "error": str(exc)})
            finally:
                processed.add(node_id)
                processing.discard(node_id)
                ready.task_done()
                for child_id in outgoing.get(node_id, []):
                    if child_id not in processed:
                        await ready.put(child_id)

    try:
        workers = [asyncio.create_task(worker(idx)) for idx in range(max_parallel)]

        stalled_ticks = 0
        while len(processed) < len(nodes_by_id):
            await asyncio.sleep(0.05)
            if ready.empty() and not processing:
                stalled_ticks += 1
                if stalled_ticks >= 20:
                    break
            else:
                stalled_ticks = 0

        for worker_task in workers:
            worker_task.cancel()
        await asyncio.gather(*workers, return_exceptions=True)

        if len(processed) != len(nodes_by_id):
            missing = sorted(set(nodes_by_id) - processed)
            raise HTTPException(status_code=400, detail=f"Scheduler stalled. Unprocessed nodes: {', '.join(missing)}")

        final_status = "finished"
        if any(status == "error" for status in run_meta["node_status"].values()):
            final_status = "error"
        elif any(status == "blocked" for status in run_meta["node_status"].values()):
            final_status = "partial"
        run_meta["status"] = final_status
        run_meta["finished_at"] = utc_now()
        await broadcast(run_id, {"type": "run_status", "run_id": run_id, "status": final_status, "node_status": run_meta["node_status"]})
    except Exception as exc:
        logger.exception("Workflow run %s failed", run_id)
        run_meta["status"] = "error"
        run_meta["finished_at"] = utc_now()
        await broadcast(run_id, {"type": "run_status", "run_id": run_id, "status": "error", "error": str(exc)})
    finally:
        write_json(run_dir / "summary.json", run_meta)


app = FastAPI(title="HackAtomIQical API", version="2.1.0-local")

_allowed_origins = os.getenv("ALLOWED_ORIGINS", "*")
allowed_origins = [item.strip() for item in _allowed_origins.split(",") if item.strip()]
allow_credentials = not (len(allowed_origins) == 1 and allowed_origins[0] == "*")
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=allow_credentials,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health() -> Dict[str, Any]:
    return {
        "status": "ok",
        "tools_loaded": len(TOOLS),
        "templates": len(read_json(TEMPLATES_FILE, [])),
        "state_dir": str(STATE_ROOT),
        "timestamp": utc_now(),
    }


@app.get("/api/tools")
def list_tools() -> Dict[str, Any]:
    return {
        "tools": [
            {
                "id": tool_id,
                "label": tool.get("label", tool_id),
                "description": tool.get("description", ""),
                "category": tool.get("category", "other"),
                "args": tool.get("args", []),
                "inputs": tool.get("inputs", []),
                "outputs": tool.get("outputs", []),
                "cmd": tool.get("cmd", []),
                "out": tool.get("out", {}),
            }
            for tool_id, tool in sorted(TOOLS.items())
        ],
        "variables": BUILTIN_VARIABLES,
    }


@app.post("/api/validate-workflow")
def validate_workflow(payload: WorkflowModel) -> Dict[str, Any]:
    validate_workflow_graph(payload)
    return {"ok": True, "nodes": len(payload.nodes), "edges": len(payload.edges)}


@app.post("/api/run")
async def start_run(payload: RunRequest) -> Dict[str, Any]:
    run_id = uuid4().hex[:12]
    RUN_EVENTS[run_id] = []
    asyncio.create_task(execute_workflow(run_id, payload))
    return {"run_id": run_id, "status": "queued", "options": payload.options.model_dump()}


@app.get("/api/runs")
def list_runs() -> Dict[str, Any]:
    runs: List[Dict[str, Any]] = []
    for summary_path in sorted(RUNS_ROOT.glob("*/summary.json"), reverse=True):
        data = read_json(summary_path, {})
        if data:
            runs.append(data)
    for run_id, data in RUN_SUMMARY.items():
        if not any(existing.get("id") == run_id for existing in runs):
            runs.append(data)
    runs.sort(key=lambda item: item.get("started_at") or "", reverse=True)
    return {"runs": runs}


@app.get("/api/runs/{run_id}")
def get_run(run_id: str) -> Dict[str, Any]:
    if run_id in RUN_SUMMARY:
        summary = RUN_SUMMARY[run_id]
    else:
        summary_path = RUNS_ROOT / run_id / "summary.json"
        summary = read_json(summary_path, None)
    if not summary:
        raise HTTPException(status_code=404, detail="Run not found")
    return summary


@app.get("/api/runs/{run_id}/artifacts")
def get_run_artifacts(run_id: str) -> Dict[str, Any]:
    summary = get_run(run_id)
    return {"run_id": run_id, "artifacts": summary.get("artifacts", {})}


@app.get("/api/runs/{run_id}/artifacts/{node_id}/{artifact_path:path}")
def download_artifact(run_id: str, node_id: str, artifact_path: str):
    candidate = (RUNS_ROOT / run_id / node_id / artifact_path).resolve()
    root = (RUNS_ROOT / run_id / node_id).resolve()
    if root not in candidate.parents and candidate != root:
        raise HTTPException(status_code=400, detail="Invalid artifact path")
    if not candidate.exists() or not candidate.is_file():
        raise HTTPException(status_code=404, detail="Artifact not found")
    return FileResponse(candidate)


@app.get("/api/templates")
def list_templates() -> Dict[str, Any]:
    return {"templates": read_json(TEMPLATES_FILE, default_templates())}


@app.post("/api/templates")
def save_template(template: TemplateModel) -> Dict[str, Any]:
    validate_workflow_graph(template.workflow)
    templates = read_json(TEMPLATES_FILE, default_templates())
    existing_index = next((idx for idx, item in enumerate(templates) if item.get("id") == template.id), None)
    payload = template.model_dump(by_alias=True)
    payload["updated_at"] = utc_now()
    if existing_index is None:
        templates.append(payload)
    else:
        templates[existing_index] = payload
    write_json(TEMPLATES_FILE, templates)
    return payload


@app.get("/api/settings")
def get_settings() -> Dict[str, Any]:
    settings = read_json(SETTINGS_FILE, DEFAULT_SETTINGS)
    settings.setdefault("execution_mode", DEFAULT_SETTINGS["execution_mode"])
    settings.setdefault("max_parallel", DEFAULT_SETTINGS["max_parallel"])
    settings.setdefault("tool_count", len(TOOLS))
    settings.setdefault("state_dir", str(STATE_ROOT))
    return settings


@app.put("/api/settings")
def put_settings(settings: SettingsModel) -> Dict[str, Any]:
    payload = settings.model_dump()
    payload["updated_at"] = utc_now()
    write_json(SETTINGS_FILE, payload)
    return payload


@app.websocket("/ws/run/{run_id}")
async def run_ws(run_id: str, websocket: WebSocket):
    await websocket.accept()
    RUN_CLIENTS.setdefault(run_id, []).append(websocket)
    for event in RUN_EVENTS.get(run_id, []):
        await websocket.send_text(json.dumps(event))
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        if websocket in RUN_CLIENTS.get(run_id, []):
            RUN_CLIENTS[run_id].remove(websocket)


if __name__ == "__main__":
    uvicorn.run("src.main:app", host="0.0.0.0", port=5000, reload=True)
