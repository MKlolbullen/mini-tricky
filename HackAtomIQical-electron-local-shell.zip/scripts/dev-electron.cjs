const path = require('node:path')
const { spawn } = require('node:child_process')
const waitOn = require('wait-on')

function npmCommand() {
  return process.platform === 'win32' ? 'npm.cmd' : 'npm'
}

const root = path.resolve(__dirname, '..')
const vite = spawn(npmCommand(), ['--prefix', 'bug-bounty-platform', 'run', 'dev', '--', '--host', '127.0.0.1', '--port', '5173'], {
  cwd: root,
  stdio: 'inherit',
  env: process.env,
})

let electron = null

async function main() {
  try {
    await waitOn({ resources: ['http-get://127.0.0.1:5173'], timeout: 30000 })
    electron = spawn(npmCommand(), ['exec', 'electron', '.'], {
      cwd: root,
      stdio: 'inherit',
      env: { ...process.env, ELECTRON_RENDERER_URL: 'http://127.0.0.1:5173' },
    })
    electron.on('exit', () => {
      vite.kill('SIGTERM')
      process.exit(0)
    })
  } catch (error) {
    console.error('Failed to start Electron dev shell:', error)
    vite.kill('SIGTERM')
    process.exit(1)
  }
}

process.on('SIGINT', () => {
  electron?.kill('SIGTERM')
  vite.kill('SIGTERM')
  process.exit(0)
})

main()
