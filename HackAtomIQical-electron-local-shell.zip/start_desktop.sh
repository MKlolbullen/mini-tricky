#!/bin/bash
set -e

if [ ! -d node_modules ]; then
  echo "[+] Installing Electron shell dependencies..."
  npm install
fi

if [ ! -d bug-bounty-platform/node_modules ]; then
  echo "[+] Installing frontend dependencies..."
  npm --prefix bug-bounty-platform install
fi

if [ ! -f bug-bounty-platform/dist/index.html ]; then
  echo "[+] Building frontend for desktop shell..."
  npm run ui:build
fi

echo "[+] Launching HackAtomIQical desktop shell..."
npm run desktop:start
