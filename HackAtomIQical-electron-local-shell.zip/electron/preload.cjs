const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('hackatomiqDesktop', {
  isDesktop: true,
  getInfo: () => ipcRenderer.invoke('desktop:get-info'),
  checkTools: (names) => ipcRenderer.invoke('desktop:check-tools', names),
  openPath: (targetPath) => ipcRenderer.invoke('desktop:open-path', targetPath),
  openExternal: (url) => ipcRenderer.invoke('desktop:open-external', url),
  selectFile: () => ipcRenderer.invoke('desktop:select-file'),
  restartBackend: () => ipcRenderer.invoke('desktop:restart-backend'),
  onReady: (callback) => {
    const handler = (_event, payload) => callback(payload)
    ipcRenderer.on('desktop:ready', handler)
    return () => ipcRenderer.removeListener('desktop:ready', handler)
  },
})
