const { app, BrowserWindow, dialog, ipcMain, shell } = require('electron')
const path = require('node:path')
const fs = require('node:fs')
const { spawn } = require('node:child_process')

const DEFAULT_BACKEND_PORT = Number(process.env.HACKATOMIQ_BACKEND_PORT || 5000)
let mainWindow = null
let backendProcess = null
let backendLogBuffer = []

function isWindows() {
  return process.platform === 'win32'
}

function repoRoot() {
  return path.resolve(__dirname, '..')
}

function resolveResourceRoot() {
  return app.isPackaged ? process.resourcesPath : repoRoot()
}

function resolveBackendRoot() {
  return path.join(resolveResourceRoot(), 'backend')
}

function resolveRendererEntry() {
  if (process.env.ELECTRON_RENDERER_URL) {
    return { type: 'url', value: process.env.ELECTRON_RENDERER_URL }
  }
  return {
    type: 'file',
    value: path.join(resolveResourceRoot(), 'bug-bounty-platform', 'dist', 'index.html'),
  }
}

function resolveBackendPython() {
  const backendRoot = resolveBackendRoot()
  const localCandidates = isWindows()
    ? [
        path.join(backendRoot, 'venv', 'Scripts', 'python.exe'),
        path.join(repoRoot(), 'backend', 'venv', 'Scripts', 'python.exe'),
      ]
    : [
        path.join(backendRoot, 'venv', 'bin', 'python3'),
        path.join(backendRoot, 'venv', 'bin', 'python'),
        path.join(repoRoot(), 'backend', 'venv', 'bin', 'python3'),
        path.join(repoRoot(), 'backend', 'venv', 'bin', 'python'),
      ]

  const envCandidates = [process.env.HACKATOMIQ_PYTHON].filter(Boolean)
  const fallback = isWindows() ? ['py', 'python', 'python3'] : ['python3', 'python']

  for (const candidate of [...envCandidates, ...localCandidates]) {
    if (candidate && fs.existsSync(candidate)) {
      return candidate
    }
  }
  return fallback[0]
}

function appendBackendLog(line) {
  if (!line) return
  backendLogBuffer.push(`${new Date().toISOString()} ${line}`)
  if (backendLogBuffer.length > 500) {
    backendLogBuffer = backendLogBuffer.slice(-500)
  }
}

async function waitForBackend(baseUrl, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  let lastError = 'backend did not respond'

  while (Date.now() < deadline) {
    try {
      const response = await fetch(`${baseUrl}/api/health`)
      if (response.ok) {
        return true
      }
      lastError = `health returned ${response.status}`
    } catch (error) {
      lastError = error?.message || String(error)
    }
    await new Promise((resolve) => setTimeout(resolve, 500))
  }

  throw new Error(lastError)
}

async function startBackend() {
  if (backendProcess && !backendProcess.killed) {
    return { apiBase: `http://127.0.0.1:${DEFAULT_BACKEND_PORT}` }
  }

  const backendRoot = resolveBackendRoot()
  const pythonBin = resolveBackendPython()
  const userDataRoot = app.getPath('userData')
  const stateDir = path.join(userDataRoot, 'state')
  const apiBase = `http://127.0.0.1:${DEFAULT_BACKEND_PORT}`

  fs.mkdirSync(stateDir, { recursive: true })

  const env = {
    ...process.env,
    PYTHONUNBUFFERED: '1',
    HACKATOMIQ_STATE_DIR: stateDir,
    TOOLS_FILE: path.join(backendRoot, 'tools.yaml'),
  }

  const args = ['-m', 'uvicorn', 'src.main:app', '--host', '127.0.0.1', '--port', String(DEFAULT_BACKEND_PORT)]

  backendProcess = spawn(pythonBin, args, {
    cwd: backendRoot,
    env,
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  })

  backendProcess.stdout?.on('data', (chunk) => appendBackendLog(String(chunk).trimEnd()))
  backendProcess.stderr?.on('data', (chunk) => appendBackendLog(String(chunk).trimEnd()))
  backendProcess.on('exit', (code, signal) => {
    appendBackendLog(`backend exited code=${code} signal=${signal}`)
    backendProcess = null
  })

  await waitForBackend(apiBase)
  return { apiBase, backendRoot, stateDir }
}

async function stopBackend() {
  if (!backendProcess || backendProcess.killed) return
  backendProcess.kill('SIGTERM')
  backendProcess = null
}

function commandForPathProbe(name) {
  return isWindows()
    ? { cmd: 'where', args: [name] }
    : { cmd: 'sh', args: ['-lc', `command -v ${JSON.stringify(name)}`] }
}

function checkCommandPresence(name) {
  return new Promise((resolve) => {
    const probe = commandForPathProbe(name)
    const child = spawn(probe.cmd, probe.args, { windowsHide: true })
    let stdout = ''
    let stderr = ''
    child.stdout?.on('data', (chunk) => {
      stdout += String(chunk)
    })
    child.stderr?.on('data', (chunk) => {
      stderr += String(chunk)
    })
    child.on('exit', (code) => {
      resolve({
        name,
        installed: code === 0,
        path: stdout.split(/\r?\n/).find(Boolean) || '',
        error: code === 0 ? '' : stderr.trim(),
      })
    })
    child.on('error', (error) => {
      resolve({ name, installed: false, path: '', error: error.message })
    })
  })
}

async function createMainWindow() {
  const splash = new BrowserWindow({
    width: 1120,
    height: 760,
    show: false,
    backgroundColor: '#09090b',
    title: 'HackAtomIQical',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  })

  mainWindow = splash
  await splash.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(`
    <html><body style="background:#09090b;color:#e4e4e7;font-family:Inter,system-ui,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
      <div style="text-align:center">
        <div style="font-size:28px;font-weight:700;letter-spacing:.03em">HackAtomIQical</div>
        <div style="margin-top:12px;color:#a1a1aa">Starting local backend and loading the builder...</div>
      </div>
    </body></html>
  `))
  splash.show()

  try {
    const backend = await startBackend()
    const entry = resolveRendererEntry()
    if (entry.type === 'url') {
      await splash.loadURL(entry.value)
    } else {
      await splash.loadFile(entry.value)
    }
    splash.webContents.on('did-finish-load', () => {
      splash.webContents.send('desktop:ready', {
        apiBase: backend.apiBase,
        stateDir: backend.stateDir,
        backendRoot: backend.backendRoot,
      })
    })
  } catch (error) {
    appendBackendLog(`startup error: ${error?.message || String(error)}`)
    await dialog.showMessageBox(splash, {
      type: 'error',
      title: 'Failed to start HackAtomIQical',
      message: 'The desktop shell could not start the local Python backend.',
      detail: `${error?.message || String(error)}\n\nCheck backend/venv, Python, and installed backend dependencies.`,
    })
  }
}

ipcMain.handle('desktop:get-info', async () => {
  const apiBase = `http://127.0.0.1:${DEFAULT_BACKEND_PORT}`
  return {
    isDesktop: true,
    apiBase,
    userData: app.getPath('userData'),
    stateDir: path.join(app.getPath('userData'), 'state'),
    backendRoot: resolveBackendRoot(),
    rendererEntry: resolveRendererEntry().value,
    backendLogs: backendLogBuffer.slice(-100),
  }
})

ipcMain.handle('desktop:select-file', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
  })
  if (result.canceled) return null
  return result.filePaths[0] || null
})

ipcMain.handle('desktop:open-path', async (_event, targetPath) => {
  if (!targetPath) return false
  const normalized = path.resolve(String(targetPath))
  if (!fs.existsSync(normalized)) return false
  const opened = await shell.openPath(normalized)
  return opened === ''
})

ipcMain.handle('desktop:open-external', async (_event, url) => {
  if (!url) return false
  await shell.openExternal(String(url))
  return true
})

ipcMain.handle('desktop:check-tools', async (_event, names) => {
  const unique = [...new Set(Array.isArray(names) ? names.filter(Boolean) : [])]
  const results = await Promise.all(unique.map((name) => checkCommandPresence(String(name))))
  return results
})

ipcMain.handle('desktop:restart-backend', async () => {
  await stopBackend()
  const backend = await startBackend()
  return backend
})

app.whenReady().then(createMainWindow)

app.on('window-all-closed', async () => {
  await stopBackend()
  if (process.platform !== 'darwin') app.quit()
})

app.on('activate', async () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    await createMainWindow()
  }
})
